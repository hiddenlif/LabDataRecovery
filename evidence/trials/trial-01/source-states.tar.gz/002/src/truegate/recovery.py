"""Reconcile retained publications without rewriting scientific or review history.

Planning is read-only. Every study is admitted as a unit, and apply holds the
writer reservation across planning, backup and the single commit.
"""
import os
from pathlib import Path
import sqlite3
import uuid
from .codec import loads, dumps, digest
from .errors import WorkbenchError
from .ingest_resolution import assemble
from .ingestion import manifest_contract
from .repository import event, now

VERSION = 'transfer-evidence-v1'
ACTION = 'transfer_evidence_recovered_v1'
PREVIEW = 'transfer_evidence_recovered_preview'


def rows(db, query, args=()):
    return [dict(row) for row in db.execute(query, args)]


def require(condition, reason):
    if not condition:
        raise WorkbenchError(reason)


def audit_study(db, cid, entry):
    journal = rows(db, 'SELECT * FROM events WHERE campaign=? ORDER BY id', (cid,))
    for record in journal:
        record['payload'] = loads(record['payload'])
        require(isinstance(record['payload'], dict), 'Journal payload must be an object')
    sessions = {r['id']: r for r in rows(db, "SELECT * FROM ingest_sessions WHERE campaign=? AND state='published'", (cid,))}
    publications = [e for e in journal if e['action'] == 'ingest_published']
    if not sessions and not publications:
        return
    datasets = {r['id']: r for r in rows(db, 'SELECT * FROM datasets WHERE campaign=? ORDER BY revision', (cid,))}

    def dataset(identifier):
        require(identifier in datasets, 'Dataset link is absent or belongs to another study: ' + str(identifier))
        row = datasets[identifier]
        require(digest(loads(row['content'])) == row['sha'], 'Stored dataset fingerprint mismatch: ' + identifier)
        return row

    for identifier in datasets:
        dataset(identifier)
    pub_by_session = {}
    for publication in publications:
        sid = publication['payload']['session']
        require(sid in sessions and sid not in pub_by_session, 'Missing or ambiguous publication session: ' + str(sid))
        dataset(publication['payload']['dataset'])
        pub_by_session[sid] = publication
    require(set(pub_by_session) == set(sessions), 'Published session lacks a unique publication event')

    contents = {}
    for sid, session in sessions.items():
        manifest = loads(session['manifest'])
        require(digest(manifest) == session['manifest_sha'], 'Manifest fingerprint mismatch: ' + sid)
        manifest_contract(manifest)
        require(manifest['delivery_id'] == session['delivery_key'] and manifest['expected_revision'] == session['expected_revision'],
                'Manifest disagrees with session identity: ' + sid)
        sources = rows(db, 'SELECT * FROM ingest_sources WHERE session=?', (sid,))
        # assemble distrusts parsed caches and checks both retained integrity records.
        try:
            contents[sid] = assemble(manifest, sources)
        except (WorkbenchError, KeyError, TypeError, ValueError, OverflowError) as exc:
            raise WorkbenchError(f'Session {sid}: {exc}') from exc
        dataset(session['published_dataset'])

    previews = [e for e in journal if e['action'] == PREVIEW]
    completed = [e for e in journal if e['action'] == ACTION]
    session_moves, job_moves = {}, {}
    provenance = {e['payload']['dataset'] for e in journal if e['action'] == 'imported'}
    for e in journal:
        if e['action'] == 'imported':
            row = dataset(e['payload']['dataset'])
            require(e['payload'].get('sha256') == row['sha'] and e['payload'].get('revision') == row['revision'],
                    'Import journal disagrees with stored dataset')
        if e['action'] not in (PREVIEW, ACTION):
            continue
        payload = e['payload']
        require(payload.get('version') == ('transfer-evidence-preview-0' if e['action'] == PREVIEW else VERSION),
                'Unsupported recovery ledger version')
        for move in payload['sessions']:
            sid = move['session']
            require(sid in sessions and pub_by_session[sid]['id'] < e['id'], 'Recovery ledger names an unpublished session')
            previous = session_moves.get(sid, pub_by_session[sid]['payload']['dataset'])
            require(move['from_dataset'] == previous, 'Recovery session provenance does not match publication')
            target = dataset(move['to_dataset'])
            require(target['sha'] == move['sha256'] == digest(contents[sid]), 'Recovery ledger content does not match retained delivery')
            session_moves[sid] = target['id']
            provenance.add(target['id'])
        for move in payload['jobs']:
            job_moves.setdefault(move['job'], []).append((e['id'], move))

    for sid, session in sessions.items():
        original = pub_by_session[sid]['payload']['dataset']
        require(session['published_dataset'] in (original, session_moves.get(sid, original)),
                'Publication pointer changed without matching recovery provenance: ' + sid)

    # Reuse verifiable partial recovery revisions, never a merely similar projection.
    allocated = max((r['revision'] for r in datasets.values()), default=0)
    targets, new_rows = {}, []
    for publication in publications:
        sid = publication['payload']['session']
        session, content = sessions[sid], contents[sid]
        sha = digest(content)
        preferred = session_moves.get(sid, session['published_dataset'])
        if dataset(preferred)['sha'] == sha:
            target = dataset(preferred)
        else:
            candidates = [r for r in datasets.values() if r['sha'] == sha and r['id'] in provenance]
            require(len(candidates) <= 1, 'Multiple matching dataset revisions have ambiguous provenance: ' + sid)
            if candidates:
                target = candidates[0]
            else:
                allocated += 1
                identifier = uuid.uuid5(uuid.NAMESPACE_URL, dumps([VERSION, cid, sid, sha])).hex
                require(not db.execute('SELECT 1 FROM datasets WHERE id=?', (identifier,)).fetchone(), 'Recovery dataset ID collision')
                target = dict(id=identifier, revision=allocated, sha=sha, content=dumps(content))
                new_rows.append(target)
        targets[sid] = target['id']
        if session['published_dataset'] != target['id']:
            entry['sessions'].append(dict(session=sid, from_dataset=session['published_dataset'],
                                          to_dataset=target['id'], revision=target['revision'], sha256=sha))

    # Replay only durable publication order, never timestamps or revision order.
    current, original_current = None, None
    submissions = {}
    for record in journal:
        action, payload = record['action'], record['payload']
        if action == 'imported':
            current = original_current = payload['dataset']
        elif action == 'ingest_published':
            current = targets[payload['session']]
            original_current = payload['dataset']
        elif action == ACTION and payload.get('current_dataset'):
            current = original_current = dataset(payload['current_dataset'])['id']
        elif action == 'job_submitted':
            submissions.setdefault(payload['job'], []).append((record['id'], payload, current, original_current))
    require(current is not None, 'No current publication can be established')

    jobs = rows(db, 'SELECT * FROM jobs WHERE campaign=? ORDER BY id', (cid,))
    job_ids = {j['id'] for j in jobs}
    require(set(job_moves) <= job_ids, 'Recovery ledger names a missing job')
    final_keys = set()
    for job in jobs:
        dataset(job['dataset'])
        submitted = submissions.get(job['id'], [])
        moves = job_moves.get(job['id'], [])
        # Even a preview move needs an unambiguous origin and an intact chain.
        if moves:
            require(len(submitted) == 1, 'Recovery job lacks a unique submission: ' + job['id'])
            previous = submitted[0][1]['dataset']
            for event_id, move in moves:
                require(event_id > submitted[0][0] and move['from_dataset'] == previous,
                        'Recovery job provenance disagrees with submission: ' + job['id'])
                dataset(move['to_dataset'])
                require(move['to_dataset'] in provenance, 'Recovery job target lacks dataset provenance')
                previous = move['to_dataset']
            require(job['dataset'] == previous, 'Job differs from recovery ledger: ' + job['id'])
        target = job['dataset']
        if job['state'] == 'queued' and job['staged'] is None and job['published_run'] is None:
            require(len(submitted) == 1, 'Waiting job lacks a unique submission event: ' + job['id'])
            _, payload, context, original = submitted[0]
            require(context is not None and payload['dataset'] == original,
                    'Waiting job submission disagrees with publication context: ' + job['id'])
            require(moves or job['dataset'] == payload['dataset'], 'Waiting job was moved without recovery provenance: ' + job['id'])
            target = context
            if target != job['dataset']:
                entry['jobs'].append(dict(job=job['id'], from_dataset=job['dataset'], to_dataset=target))
        key = (target, job['policy_sha'], job['engine'])
        require(key not in final_keys, 'Recovery would collide with another analysis job key')
        final_keys.add(key)

    if completed and not entry['sessions'] and not entry['jobs'] and not new_rows:
        # Keep the original mapping in the repeat report, even after jobs complete
        # or a later ordinary import advances the current dataset.
        saved = completed[-1]['payload']
        entry.update({k: saved[k] for k in ('sessions', 'jobs', 'runs', 'decisions')})
        entry['status'] = 'already_recovered'
        entry['current_dataset'] = current
        return
    if not entry['sessions'] and not entry['jobs'] and not previews:
        return
    entry.update(status='recoverable', current_dataset=current, version=VERSION,
                 _new_rows=new_rows,
                 runs=[dict(run=r['id'], dataset=r['dataset'], action='preserved') for r in rows(db, 'SELECT id,dataset FROM runs WHERE campaign=? ORDER BY id', (cid,))],
                 decisions=[dict(decision=d['id'], run=d['run'], action='preserved') for d in rows(db, 'SELECT id,run FROM decisions WHERE campaign=? ORDER BY id', (cid,))])


def plan(db):
    studies = []
    for campaign in rows(db, 'SELECT id FROM campaigns ORDER BY id'):
        entry = dict(campaign=campaign['id'], status='unaffected', sessions=[], jobs=[], runs=[], decisions=[], unresolved=[])
        try:
            audit_study(db, campaign['id'], entry)
        except (WorkbenchError, KeyError, TypeError, ValueError, OverflowError) as exc:
            entry = dict(campaign=campaign['id'], status='blocked', sessions=[], jobs=[], runs=[], decisions=[],
                         unresolved=[dict(reason=str(exc))])
        studies.append(entry)
    return studies


def public(studies, mode, backup=None):
    return dict(version=VERSION, mode=mode, backup=str(backup) if backup else None,
                studies=[{k: v for k, v in entry.items() if not k.startswith('_')} for entry in studies])


def recover(path, dry_run=False, backup=None):
    path = Path(path).resolve()
    if not path.is_file():
        raise WorkbenchError('An existing database is required')
    db = sqlite3.connect(path.as_uri() + '?mode=' + ('ro' if dry_run else 'rw'), uri=True, isolation_level=None, timeout=30)
    db.row_factory = sqlite3.Row
    try:
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('BEGIN' if dry_run else 'BEGIN IMMEDIATE')
        studies = plan(db)
        if dry_run:
            db.rollback()
            return public(studies, 'dry_run')
        if backup is None:
            raise WorkbenchError('Apply requires a new backup destination')
        backup = Path(backup).absolute()
        if backup.resolve() == path or backup.exists() or backup.is_symlink():
            raise WorkbenchError('Choose a new backup destination')
        backup.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(backup, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(fd)
        # A separate reader snapshots committed evidence under our writer lock.
        reader = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
        destination = sqlite3.connect(str(backup))
        try:
            reader.backup(destination)
        finally:
            destination.close()
            reader.close()
        for entry in studies:
            if entry['status'] != 'recoverable':
                continue
            cid = entry['campaign']
            for row in entry['_new_rows']:
                db.execute('INSERT INTO datasets VALUES (?,?,?,?,?,?)',
                           (row['id'], cid, row['revision'], row['sha'], row['content'], now()))
            for correction in entry['sessions']:
                db.execute('UPDATE ingest_sessions SET published_dataset=? WHERE id=?',
                           (correction['to_dataset'], correction['session']))
            # Vacate moving keys first so even a valid permutation is atomic.
            policies = {}
            for move in entry['jobs']:
                policies[move['job']] = db.execute('SELECT policy_sha FROM jobs WHERE id=?', (move['job'],)).fetchone()[0]
                db.execute('UPDATE jobs SET policy_sha=? WHERE id=?', ('recovery-' + uuid.uuid4().hex, move['job']))
            for move in entry['jobs']:
                db.execute('UPDATE jobs SET dataset=?,policy_sha=? WHERE id=?',
                           (move['to_dataset'], policies[move['job']], move['job']))
            entry['status'] = 'recovered'
            event(db, cid, ACTION, {k: v for k, v in entry.items() if not k.startswith('_')})
        db.commit()
        return public(studies, 'apply', backup)
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()
