#!/usr/bin/env python3
"""Execute the documented recovery CLI on a new copy and save verifiable reports.

PYTHONPATH=src python scripts/recover_incident.py /workspace/recovery-report
The output directory must not already exist. The supplied evidence is read-only.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'examples/recovery-incident/study.db'


def rows(path):
    with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as db:
        return {name: db.execute(f'SELECT * FROM {name} ORDER BY rowid').fetchall()
                for name, in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}


def write(path, result):
    path.write_text(json.dumps(result, indent=2, sort_keys=True) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('directory', type=Path)
    out = parser.parse_args().directory.resolve()
    out.mkdir(parents=True, exist_ok=False)
    original_sha = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    path = out / 'study.db'
    with sqlite3.connect(SOURCE.as_uri() + '?mode=ro', uri=True) as source, sqlite3.connect(path) as copy:
        source.backup(copy)
    before = rows(path)

    def execute(name, *options):
        command = [sys.executable, '-m', 'truegate.cli', 'evidence-recover', '--db', str(path), *options]
        result = json.loads(subprocess.check_output(command, cwd=ROOT, text=True))
        write(out / name, result)
        return result

    preview = execute('dry-run.json', '--dry-run')
    assert rows(path) == before
    applied = execute('apply.json', '--backup', str(out / 'before.db'))
    assert rows(out / 'before.db') == before
    after = rows(path)
    repeat = execute('repeat.json', '--backup', str(out / 'before-repeat.db'))
    assert rows(path) == rows(out / 'before-repeat.db') == after
    for planned, actual, again in zip(preview['studies'], applied['studies'], repeat['studies']):
        expected = dict(planned, status='recovered') if planned['status'] == 'recoverable' else planned
        assert actual == expected
        assert again['status'] == ('already_recovered' if actual['status'] == 'recovered' else actual['status'])
        assert actual['sessions'] == again['sessions'] and actual['jobs'] == again['jobs']
    for table in ('campaigns', 'runs', 'decisions', 'ingest_sources', 'ingest_attempts', 'job_attempts'):
        assert before[table] == after[table]
    for table in ('datasets', 'events'):
        assert after[table][:len(before[table])] == before[table]
    with sqlite3.connect(path) as db:
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert db.execute('PRAGMA foreign_key_check').fetchall() == []
    check = subprocess.run([sys.executable, str(ROOT / 'examples/recovery-incident/check_consistency.py'), str(path)],
                           cwd=ROOT, capture_output=True, text=True)
    partial = json.loads(check.stdout)
    write(out / 'partial-consistency.json', partial)
    assert not partial['violations']
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == original_sha
    summary = dict(source_sha256=original_sha, statuses=dict(Counter(e['status'] for e in applied['studies'])),
                   appended_datasets=len(after['datasets']) - len(before['datasets']),
                   appended_events=len(after['events']) - len(before['events']),
                   sessions_relinked=sum(len(e['sessions']) for e in applied['studies']),
                   jobs_rebound=sum(len(e['jobs']) for e in applied['studies']),
                   preserved_runs=len(before['runs']), preserved_decisions=len(before['decisions']),
                   checks=['read-only preview', 'consistent pre-mutation backup', 'preview/apply agreement',
                           'repeat safety', 'immutable evidence and historical results', 'SQLite integrity',
                           'partial operational consistency', 'supplied database unchanged'])
    write(out / 'validation.json', summary)
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
