# Screening evidence recovery

The live workflow now identifies a dataset by its complete input fingerprint.
Previously, imports also compared a numerical projection, allowing corrected
transfer volumes, operation revisions, lineage and exact source bytes to reuse
an older dataset and its review. Job submission also omitted the dataset from
its reuse query. Export grouped transfer bindings by compound and dose, dropping
distinct wells with equal concentrations. These reuse/grouping defects are fixed.
Historical snapshots continue to read the stored result and original input;
they do not rerun the current engine or transfer an earlier review to new evidence.

Instrument parsing now uses the manifest's transfer codec in both staging and
complete-delivery assembly. Legacy `transfer-history/1` uses exclusive boundaries;
its binding sequence is normalized by subtracting one after strict integer
validation. Version 2 uses inclusive boundaries. Unknown codecs reject the source.
Complete assembly checks retained byte and source fingerprints and ignores parsed
caches. Existing physical replay and full-delivery validation continue to reject
unmatched samples, conflicting plates and measured overdrafts.

## Executed migration

Run the executable report on another fresh copy:

```sh
PYTHONPATH=src python scripts/recover_incident.py /workspace/new-recovery-report
```

The executed artifacts are in [recovery-report](recovery-report/):

- [dry-run.json](recovery-report/dry-run.json): read-only plan.
- [apply.json](recovery-report/apply.json): actual session/job mappings and preserved run/decision IDs.
- [repeat.json](recovery-report/repeat.json): durable mappings returned as `already_recovered`.
- [validation.json](recovery-report/validation.json): counts and executed checks.
- `study.db`: migrated copy; `before.db`: consistent pre-mutation backup;
  `before-repeat.db`: backup taken for the no-change repeat apply.
- [partial-consistency.json](recovery-report/partial-consistency.json): supplied operational diagnostic.

| Outcome | Count |
| --- | ---: |
| Recovered studies | 18 |
| Unaffected studies | 12 |
| Blocked studies | 10 |
| Appended datasets | 20 |
| Relinked delivery sessions | 24 |
| Rebound queued jobs | 24 |
| Recovery journal events | 18 |
| Preserved stored runs | 40 |
| Preserved review decisions | 40 |

Recovered study names end in **7100, 7101, 7103, 7105, 7107, 7110, 7113,
7119, 7125, 7126, 7127, 7130, 7132, 7134, 7136, 7137, 7138, 7139**.
The JSON reports contain the complete campaign and record identifiers.
The four previously appended datasets in partial recoveries 7138 and 7139 were
verified and adopted, explaining why 24 relinked deliveries required only 20
new datasets. Their incorrectly pinned earlier queued jobs were moved back to
the evidence available at submission. Their preview audit records remain intact.

Publication and submission order comes from journal IDs, not display timestamps
or revision numbers. Recovery records a separate current-dataset selection, so
reconstructing an earlier suppressed delivery does not displace a later valid
instrument publication or direct import. Revision allocation remains monotonic;
`show.current_revision` is the concurrency token, while snapshots retain their
actual dataset revision. Ordinary later imports supersede the recovery selection.
Existing running/staged/completed jobs, attempts, source bytes, dataset contents,
results, decisions and old journal records were preserved.

The supplied database was not modified. Its SHA-256 remains
`bc4de222fc76eece5b91eb1a95ec7b4ee23d8de7e991bde5287a9ceea83f1a27`.

## Blocked evidence

Each blocked study was left entirely unchanged; no dataset, pointer, job or
recovery event was partially applied. Recovering these requires authoritative
missing evidence or a documented format specification, followed by a fresh audit.

| Study | Campaign | Blocking evidence |
| --- | --- | --- |
| 7102 | `18777fb11c3f4161ad5b9b159867dde8` | Original history bytes missing from session `f6e98a0f441f4008a2151a68641ba7d5` |
| 7104 | `a9f225a576ce44bdad197d5d2c05fb51` | Original history bytes missing from session `9c991a671e1e4cf7bf8d12a79a12d8ba` |
| 7108 | `f082fa4fc4844a3ebff5d737204dbfc1` | Submission event missing for queued job `3c5336b236264c3a93e44b929f5ca658` |
| 7109 | `115de33b245042faa8ee3bd3ddb289bd` | Submission event missing for queued job `20650986a07c4e9e93794377e3aa0d84` |
| 7112 | `88c454cf4e314193922389580cd44766` | Submission event missing for queued job `735e3506954c4ef08c911228fda426fe` |
| 7118 | `0a70e2995cec4829a4e30b94153521f6` | Original history bytes missing from session `d7d3da2698994276bd71e31a2a76e7e1` |
| 7122 | `6c9b34b96363425cb44be867950c6957` | Original history bytes missing from session `16f8065e8e5a489eae367a28a8f5abc0` |
| 7123 | `b72b611d310c4e5a953fed8cc6b7a326` | Submission event missing for queued job `7c7cd9abc0ed4aa5939bfb65181450c7` |
| 7133 | `259c706e496b477788c07d033e47b317` | Session `2c416fae4c8a463eb2c16a3fa2b332b6` declares unsupported `transfer-history/unknown` |
| 7135 | `e3f589589e8d4a53af162c3b8d5409b0` | Session `ef19f45191fb492e8a4bde5b5557f138` declares unsupported `transfer-history/unknown` |

Parsed caches cannot replace missing original bytes. Timestamps cannot replace
missing submission events. An unknown codec cannot safely be treated as version
1 or 2 because the selected physical snapshot can differ.

The supplied partial checker reports **zero violations**. Its unresolved section
also lists the four repaired studies with later direct imports (7100, 7103, 7110,
7126): that diagnostic deliberately stops at a later direct import and does not
interpret recovery's current-dataset ledger. These four studies are recovered,
with their later direct inputs still current. The ten studies above remain blocked.

## Validation

`PYTHONPATH=src python -m pytest -q --basetemp=/workspace/.pytest-tmp` passes
**64 tests**. Regression coverage includes complete evidence identity, pinned
jobs and lease fencing, historical snapshots, equal-dose distinct report rows,
codec boundaries and malformed inputs, missing/tampered evidence, ambiguous
journal records, partial preview adoption, job-key collisions, later current
publications, repeat safety, WAL-aware readable backups and whole-apply rollback.

The executable report additionally checks preview/apply agreement, exact retained
rows in immutable tables, original dataset/event prefixes, unchanged source
database, SQLite integrity and foreign keys, and no mutation on repeated apply.
Recovery holds a SQLite writer reservation through planning, backup and commit.
Unexpected apply errors roll back all admitted studies together. Every apply,
including a no-change apply, requires a new absolute backup destination.
