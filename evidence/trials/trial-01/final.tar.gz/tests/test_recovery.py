"""Recovery tests construct independent histories, not fixture-specific IDs."""
from copy import deepcopy
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys

import pytest

from truegate.codec import digest, dumps, loads
from truegate.database import transaction
from truegate.errors import WorkbenchError
from truegate.ingestion import Ingestion
from truegate.instrument_files import parse
from truegate.jobs import Jobs
from truegate.recovery import ACTION, PREVIEW, recover
from truegate.reporting import export, verify
from truegate.repository import Repository, event, latest_dataset, now
from test_correction_lifecycle import evidence, correction, stage


def database_rows(path):
    with sqlite3.connect(path) as db:
        return {name: db.execute(f'SELECT * FROM {name} ORDER BY rowid').fetchall()
                for name, in db.execute("SELECT name FROM sqlite_master WHERE type='table' AND name NOT LIKE 'sqlite_%'")}


def incident(path, monkeypatch, later=False):
    repo, ingest, jobs = Repository(path), Ingestion(path), Jobs(path)
    cid = repo.create('Independent retained evidence', 'screening')['campaign']
    initial = evidence()
    first, _ = stage(ingest, cid, initial, 'first', 0)
    original = ingest.publish(first)
    run = repo.run(cid)['run']
    repo.review(cid, run, 'accept', 'Reviewer', 'Original inspection', 1)
    early = jobs.submit(cid)['job']
    staged = jobs.submit(cid, {'min_doses': 7})['job']
    token = jobs.claim(staged, 'worker', 300)['token']
    jobs.compute(staged, token)
    second, _ = stage(ingest, cid, correction(initial), 'second', 1)
    corrected = ingest.preview(second)['input']
    with monkeypatch.context() as patch:
        patch.setattr('truegate.ingestion.store_dataset', lambda *a: dict(original, reused=True))
        ingest.publish(second)
    waiting = jobs.submit(cid, {'min_doses': 8})['job']
    newest = None
    if later:
        third_data = correction(initial)
        third_data['transfer_history']['revision'] = 'newest'
        third, _ = stage(ingest, cid, third_data, 'third', 1)
        newest = ingest.publish(third)
    return dict(cid=cid, first=first, second=second, original=original, corrected=corrected,
                early=early, waiting=waiting, staged=staged, token=token, run=run, newest=newest)


def test_recovery_backup_pinning_preservation_and_repeat(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    f = incident(path, monkeypatch)
    before_bytes, before = path.read_bytes(), database_rows(path)
    preview = recover(path, dry_run=True)
    assert path.read_bytes() == before_bytes
    assert sorted(p.name for p in tmp_path.iterdir()) == ['study.db']
    entry = preview['studies'][0]
    assert entry['status'] == 'recoverable' and len(entry['sessions']) == len(entry['jobs']) == 1
    target = entry['sessions'][0]['to_dataset']
    assert entry['sessions'][0]['sha256'] == digest(f['corrected'])
    assert entry['jobs'] == [dict(job=f['waiting'], from_dataset=f['original']['dataset'], to_dataset=target)]
    backup = tmp_path / 'backup.db'
    applied = recover(path, backup=backup)
    assert applied['studies'][0] == dict(entry, status='recovered')
    assert database_rows(backup) == before
    after = database_rows(path)
    for table in ('runs', 'decisions', 'ingest_sources', 'ingest_attempts', 'job_attempts'):
        assert before[table] == after[table]
    assert after['datasets'][:len(before['datasets'])] == before['datasets']
    assert after['events'][:len(before['events'])] == before['events']
    repo, jobs = Repository(path), Jobs(path)
    assert repo.show(f['cid'])['current_review'] is None
    historical = repo.snapshot(f['cid'], f['run'])
    assert historical['superseded'] and historical['review']['action'] == 'accept'
    published = jobs.publish(f['staged'], f['token'])
    assert repo.snapshot(f['cid'], published['run'])['input'] == historical['input']
    token = jobs.claim(f['waiting'], 'resumed', 300)['token']
    jobs.compute(f['waiting'], token)
    run = jobs.publish(f['waiting'], token)['run']
    assert repo.snapshot(f['cid'], run)['input'] == f['corrected']
    stable = database_rows(path)
    repeated = recover(path, backup=tmp_path / 'repeat-backup.db')['studies'][0]
    assert repeated['status'] == 'already_recovered'
    assert repeated['sessions'] == entry['sessions'] and repeated['jobs'] == entry['jobs']
    assert database_rows(path) == stable
    assert database_rows(tmp_path / 'repeat-backup.db') == stable


@pytest.mark.parametrize('direct', [False, True])
def test_later_publication_stays_current_and_revision_tokens_advance(tmp_path, monkeypatch, direct):
    path = tmp_path / 'study.db'
    f = incident(path, monkeypatch, later=not direct)
    repo, jobs = Repository(path), Jobs(path)
    if direct:
        data = correction(evidence())
        data['transfer_history']['revision'] = 'later-direct'
        f['newest'] = repo.import_data(f['cid'], data)
    run = repo.run(f['cid'])['run']
    repo.review(f['cid'], run, 'accept', 'Reviewer', 'Latest delivery', 2)
    snap = repo.snapshot(f['cid'], run)
    recover(path, backup=tmp_path / 'backup.db')
    with transaction(path) as db:
        assert latest_dataset(db, f['cid'])['id'] == f['newest']['dataset']
    assert repo.snapshot(f['cid'], run) == snap
    assert repo.show(f['cid'])['current_review']['run'] == run
    assert repo.show(f['cid'])['current_revision'] == 3
    assert repo.import_data(f['cid'], snap['input'])['reused']
    repo.review(f['cid'], run, 'hold', 'Reviewer', 'Refresh', 3)
    submitted = jobs.submit(f['cid'])['job']
    with sqlite3.connect(path) as db:
        assert db.execute('SELECT dataset FROM jobs WHERE id=?', (submitted,)).fetchone()[0] == f['newest']['dataset']
    changed = deepcopy(snap['input'])
    changed['transfer_history']['revision'] = 'after-recovery'
    assert repo.import_data(f['cid'], changed)['revision'] == 4
    assert recover(path, dry_run=True)['studies'][0]['status'] == 'already_recovered'
    with transaction(path) as db:
        assert latest_dataset(db, f['cid'])['sha'] == digest(changed)


@pytest.mark.parametrize('damage', ['raw', 'source_sha', 'manifest_sha', 'missing_source', 'manifest_shape',
                                    'missing_submit', 'duplicate_submit', 'missing_publication', 'duplicate_publication',
                                    'untracked_job_move', 'bad_preview'])
def test_blocked_study_is_untouched_while_other_studies_recover(tmp_path, monkeypatch, damage):
    path = tmp_path / 'study.db'
    bad = incident(path, monkeypatch)
    good = incident(path, monkeypatch)
    with transaction(path) as db:
        if damage in ('raw', 'source_sha'):
            db.execute(f'UPDATE ingest_sources SET {"raw=NULL" if damage == "raw" else "sha=\'wrong\'"} WHERE session=? AND source_id=?', (bad['second'], 'transfer_history'))
        elif damage == 'manifest_sha':
            db.execute("UPDATE ingest_sessions SET manifest_sha='wrong' WHERE id=?", (bad['second'],))
        elif damage == 'missing_source':
            db.execute('DELETE FROM ingest_attempts WHERE session=? AND source_id=?', (bad['second'], 'transfer_history'))
            db.execute('DELETE FROM ingest_sources WHERE session=? AND source_id=?', (bad['second'], 'transfer_history'))
        elif damage == 'manifest_shape':
            db.execute('UPDATE ingest_sessions SET manifest=?,manifest_sha=? WHERE id=?', ('[]', digest([]), bad['second']))
        elif damage in ('missing_submit', 'duplicate_submit'):
            payload = db.execute("SELECT payload FROM events WHERE action='job_submitted' AND json_extract(payload,'$.job')=?", (bad['waiting'],)).fetchone()[0]
            if damage == 'missing_submit':
                db.execute("DELETE FROM events WHERE action='job_submitted' AND payload=?", (payload,))
            else:
                event(db, bad['cid'], 'job_submitted', loads(payload))
        elif damage in ('missing_publication', 'duplicate_publication'):
            payload = db.execute("SELECT payload FROM events WHERE action='ingest_published' AND json_extract(payload,'$.session')=?", (bad['second'],)).fetchone()[0]
            if damage == 'missing_publication':
                db.execute("DELETE FROM events WHERE action='ingest_published' AND payload=?", (payload,))
            else:
                event(db, bad['cid'], 'ingest_published', loads(payload))
        elif damage == 'untracked_job_move':
            db.execute('UPDATE jobs SET dataset=? WHERE id=?', (good['original']['dataset'], bad['waiting']))
        else:
            event(db, bad['cid'], PREVIEW, dict(version='transfer-evidence-preview-0', jobs=[], sessions=[dict(
                session=bad['second'], from_dataset=bad['original']['dataset'], to_dataset=bad['original']['dataset'], sha256='wrong')]))
    before = database_rows(path)
    plan = recover(path, dry_run=True)
    entries = {s['campaign']: s for s in plan['studies']}
    assert entries[bad['cid']]['status'] == 'blocked'
    assert entries[bad['cid']]['sessions'] == entries[bad['cid']]['jobs'] == []
    assert entries[good['cid']]['status'] == 'recoverable'
    recover(path, backup=tmp_path / 'backup.db')
    after = database_rows(path)
    # The only differences belong to the admitted study, including all journal changes.
    for table, values in before.items():
        if table in ('datasets', 'events'):
            assert all(row in after[table] for row in values)
        elif table not in ('jobs', 'ingest_sessions'):
            assert after[table] == values
    with sqlite3.connect(path) as db:
        assert db.execute('SELECT published_dataset FROM ingest_sessions WHERE id=?', (bad['second'],)).fetchone()[0] == bad['original']['dataset']


def test_partial_preview_is_adopted_and_wrong_waiting_pin_is_repaired(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    f = incident(path, monkeypatch)
    preview_target = 'earlier-tool-dataset'
    with transaction(path) as db:
        db.execute('INSERT INTO datasets VALUES (?,?,?,?,?,?)', (preview_target, f['cid'], 2, digest(f['corrected']), dumps(f['corrected']), now()))
        db.execute('UPDATE jobs SET dataset=? WHERE id=?', (preview_target, f['early']))
        event(db, f['cid'], PREVIEW, dict(version='transfer-evidence-preview-0', sessions=[dict(
            session=f['second'], from_dataset=f['original']['dataset'], to_dataset=preview_target, sha256=digest(f['corrected']))],
            jobs=[dict(job=f['early'], from_dataset=f['original']['dataset'], to_dataset=preview_target)]))
    planned = recover(path, dry_run=True)['studies'][0]
    assert planned['status'] == 'recoverable'
    assert planned['sessions'][0]['to_dataset'] == preview_target
    assert {m['job']: m['to_dataset'] for m in planned['jobs']} == {f['early']: f['original']['dataset'], f['waiting']: preview_target}
    recover(path, backup=tmp_path / 'backup.db')
    with sqlite3.connect(path) as db:
        assert db.execute('SELECT COUNT(*) FROM datasets').fetchone()[0] == 2
    assert recover(path, backup=tmp_path / 'second.db')['studies'][0]['status'] == 'already_recovered'


def test_job_key_collision_blocks_entire_study(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    f = incident(path, monkeypatch)
    with transaction(path) as db:
        target = 'partial'
        db.execute('INSERT INTO datasets VALUES (?,?,?,?,?,?)', (target, f['cid'], 2, digest(f['corrected']), dumps(f['corrected']), now()))
        event(db, f['cid'], PREVIEW, dict(version='transfer-evidence-preview-0', sessions=[dict(
            session=f['second'], from_dataset=f['original']['dataset'], to_dataset=target, sha256=digest(f['corrected']))], jobs=[]))
        # An existing running job at the destination must retain its input/key.
        waiting = dict(db.execute('SELECT * FROM jobs WHERE id=?', (f['waiting'],)).fetchone())
        db.execute("INSERT INTO jobs(id,campaign,dataset,policy_sha,policy,engine,state) VALUES (?,?,?,?,?,?,'running')",
                   ('occupied', f['cid'], target, waiting['policy_sha'], waiting['policy'], waiting['engine']))
    before = database_rows(path)
    result = recover(path, backup=tmp_path / 'backup.db')['studies'][0]
    assert result['status'] == 'blocked' and 'collide' in result['unresolved'][0]['reason']
    assert database_rows(path) == before


def test_apply_failure_rolls_back_all_studies_and_backup_is_readable(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    incident(path, monkeypatch)
    incident(path, monkeypatch)
    with sqlite3.connect(path) as db:
        db.execute(f"CREATE TRIGGER fail_recovery BEFORE INSERT ON events WHEN NEW.action='{ACTION}' AND (SELECT COUNT(*) FROM events WHERE action='{ACTION}') >= 1 BEGIN SELECT RAISE(ABORT,'injected'); END")
    before = database_rows(path)
    with pytest.raises(sqlite3.IntegrityError, match='injected'):
        recover(path, backup=tmp_path / 'backup.db')
    assert database_rows(path) == database_rows(tmp_path / 'backup.db') == before
    for target in (path, tmp_path / 'backup.db'):
        with pytest.raises(WorkbenchError):
            recover(path, backup=target)
    link = tmp_path / 'alias.db'
    link.symlink_to(path)
    with pytest.raises(WorkbenchError):
        recover(path, backup=link)
    with pytest.raises(WorkbenchError):
        recover(path)
    assert database_rows(path) == before


def test_legacy_codec_validation_and_inclusive_binding():
    model = evidence()['transfer_history']
    legacy = deepcopy(model)
    for binding in legacy['bindings']:
        binding['sequence'] += 1
    rows, errors = parse(dumps(legacy).encode(), 'transfer_history', 'transfer-history/1')
    assert not errors and rows[0]['record'] == model
    for malformed in (None, [], {}, {'bindings': [None]}, {'bindings': [{'sequence': True}]},
                      {'bindings': [{'sequence': 1.5}]}, {'bindings': [{'sequence': 0}]}):
        rows, errors = parse(dumps(malformed).encode(), 'transfer_history', 'transfer-history/1')
        assert not rows and errors[0]['line'] == 0


def test_export_keeps_equal_dose_distinct_wells(tmp_path):
    path = tmp_path / 'study.db'
    repo = Repository(path)
    cid = repo.create('Replicate wells', 'screening')['campaign']
    repo.import_data(cid, evidence())
    snap = repo.snapshot(cid, repo.run(cid)['run'])
    destination = tmp_path / 'report'
    export(snap, destination)
    with (destination / 'transfer-bindings.csv').open() as stream:
        bindings = list(csv.DictReader(stream))
    assert {b['record_id'] for b in bindings} == {'early', 'late'}
    assert len(bindings) == 2 and len({b['dose_um'] for b in bindings}) == 1
    assert verify(destination)['verified']


def test_cli_readonly_preview_and_wal_backup(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    incident(path, monkeypatch)
    with sqlite3.connect(path) as writer:
        writer.execute('PRAGMA journal_mode=WAL')
        writer.execute("UPDATE ingest_sources SET parsed='stale cache'")
        writer.commit()
        before = database_rows(path)
        args = [sys.executable, '-m', 'truegate.cli', 'evidence-recover', '--db', str(path)]
        preview = json.loads(subprocess.check_output(args + ['--dry-run'], text=True))
        assert preview['backup'] is None and preview['mode'] == 'dry_run'
        assert database_rows(path) == before
        applied = json.loads(subprocess.check_output(args + ['--backup', str(tmp_path / 'backup.db')], text=True))
        assert applied['studies'][0]['status'] == 'recovered'
        assert database_rows(tmp_path / 'backup.db') == before


def test_supplied_incident_reconciles_and_repeats(tmp_path):
    path = tmp_path / 'study.db'
    shutil.copyfile(Path(__file__).resolve().parents[1] / 'examples/recovery-incident/study.db', path)
    before = database_rows(path)
    plan = recover(path, dry_run=True)
    assert {e['status'] for e in plan['studies']} == {'recoverable', 'blocked', 'unaffected'}
    applied = recover(path, backup=tmp_path / 'backup.db')
    repeated = recover(path, backup=tmp_path / 'repeat.db')
    for planned, actual, again in zip(plan['studies'], applied['studies'], repeated['studies']):
        assert actual == dict(planned, status='recovered') if planned['status'] == 'recoverable' else actual == planned
        assert again['status'] == ('already_recovered' if actual['status'] == 'recovered' else actual['status'])
    after = database_rows(path)
    for table in ('runs', 'decisions', 'ingest_sources', 'ingest_attempts', 'job_attempts'):
        assert before[table] == after[table]
