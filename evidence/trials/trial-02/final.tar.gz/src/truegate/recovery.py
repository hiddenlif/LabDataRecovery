"""Reconcile retained deliveries using immutable bytes and the append-only journal.

Planning is read-only. Each study is admitted as a whole, before any apply writes;
allocation order is deliberately independent of evidence/publication order.
"""
import os
from pathlib import Path
import sqlite3
from .codec import loads, dumps, digest
from .errors import WorkbenchError
from .ingest_resolution import assemble
from .repository import event, now

VERSION = 'transfer-evidence-v1'
ACTION = 'transfer_evidence_recovered_v1'
PREVIEW = 'transfer_evidence_recovered_preview'


def rows(db, query, args=()):
    return [dict(row) for row in db.execute(query, args)]


def require(condition, reason):
    if not condition:
        raise WorkbenchError(reason)


def audit(db, entry):
    cid = entry['campaign']
    sessions = {s['id']: s for s in rows(db, "SELECT * FROM ingest_sessions WHERE campaign=? AND state='published'", (cid,))}
    journal = rows(db, 'SELECT * FROM events WHERE campaign=? ORDER BY id', (cid,))
    for e in journal:
        e['payload'] = loads(e['payload'])
        require(isinstance(e['payload'], dict), 'Journal payload is not an object')
    publications = [e for e in journal if e['action'] == 'ingest_published']
    if not sessions and not publications:
        return
    datasets = {d['id']: d for d in rows(db, 'SELECT * FROM datasets WHERE campaign=? ORDER BY revision', (cid,))}
    jobs = {j['id']: j for j in rows(db, 'SELECT * FROM jobs WHERE campaign=? ORDER BY id', (cid,))}
    for d in datasets.values():
        require(digest(loads(d['content'])) == d['sha'], 'Dataset fingerprint mismatch: ' + d['id'])
    pubs = {}
    for e in publications:
        p = e['payload']; sid = p['session']
        require(sid in sessions and sid not in pubs, 'Missing or ambiguous publication session: ' + sid)
        require(p['dataset'] in datasets, 'Published dataset is absent from the study: ' + sid)
        pubs[sid] = e
    require(set(pubs) == set(sessions), 'Published session lacks a unique publication event')

    contents = {}
    for sid, session in sessions.items():
        manifest = loads(session['manifest'])
        require(digest(manifest) == session['manifest_sha'], 'Manifest fingerprint mismatch: ' + sid)
        require(manifest['delivery_id'] == session['delivery_key'] and
                manifest['expected_revision'] == session['expected_revision'], 'Session and manifest disagree: ' + sid)
        sources = rows(db, 'SELECT * FROM ingest_sources WHERE session=?', (sid,))
        contents[sid] = assemble(manifest, sources)

    # A ledger may explain pointers changed by earlier recovery. Its contents
    # must still be independently verifiable; a matching hash alone is not provenance.
    session_paths = {sid: pubs[sid]['payload']['dataset'] for sid in sessions}
    job_paths = {}
    submissions = {}
    for e in journal:
        if e['action'] == 'job_submitted':
            p = e['payload']
            submissions.setdefault(p['job'], []).append(e)
    for jid, submitted in submissions.items():
        if len(submitted) == 1:
            job_paths[jid] = submitted[0]['payload']['dataset']
    adopted = {}
    completed = []
    finalized_sessions = set()
    explained = set()
    for e in journal:
        if e['action'] == 'imported':
            p = e['payload']; d = datasets.get(p['dataset'])
            require(d is not None and d['sha'] == p['sha256'] and d['revision'] == p['revision'],
                    'Import journal disagrees with dataset')
            explained.add(d['id'])
        if e['action'] not in (PREVIEW, ACTION):
            continue
        p = e['payload']
        if e['action'] == PREVIEW:
            require(p['version'] == 'transfer-evidence-preview-0', 'Unsupported preview ledger version')
        else:
            require(p.get('version', VERSION) == VERSION, 'Unsupported recovery ledger version')
            completed.append(e)
        for m in p['sessions']:
            sid = m['session']; target = datasets.get(m['to_dataset'])
            require(sid in contents and pubs[sid]['id'] < e['id'], 'Recovery ledger references an unknown publication')
            require(target is not None and target['sha'] == m['sha256'] == digest(contents[sid]) and
                    loads(target['content']) == contents[sid], 'Recovery ledger input mismatch: ' + sid)
            allowed_from = {session_paths[sid]}
            if sid not in finalized_sessions:
                allowed_from.add(pubs[sid]['payload']['dataset'])
            require(m['from_dataset'] in allowed_from, 'Recovery ledger session ancestry mismatch: ' + sid)
            if e['action'] == ACTION:
                finalized_sessions.add(sid)
            if 'revision' in m:
                require(m['revision'] == target['revision'], 'Recovery ledger revision mismatch: ' + sid)
            session_paths[sid] = target['id']
            adopted[sid] = target['id']
            explained.add(target['id'])
        ledger_targets = {m['to_dataset'] for m in p['sessions']}
        for m in p['jobs']:
            jid = m['job']
            if e['action'] == PREVIEW:
                require(m['to_dataset'] in ledger_targets, 'Preview job target has no verified delivery provenance: ' + jid)
            require(jid in jobs and job_paths.get(jid) == m['from_dataset'] and m['to_dataset'] in datasets,
                    'Recovery ledger job ancestry mismatch: ' + jid)
            job_paths[jid] = m['to_dataset']
    require(set(datasets) <= explained, 'Dataset has no import or recovery provenance')
    for sid, session in sessions.items():
        # Preview migrations could leave the publication pointer unchanged.
        allowed = {pubs[sid]['payload']['dataset'], session_paths[sid]}
        require(session['published_dataset'] in allowed, 'Unexplained publication pointer: ' + sid)
        if completed and sid in {m['session'] for e in completed for m in e['payload']['sessions']}:
            require(session['published_dataset'] == session_paths[sid], 'Completed recovery publication pointer changed: ' + sid)

    revision = max((d['revision'] for d in datasets.values()), default=0)
    targets, additions = {}, []
    for e in publications:
        sid = e['payload']['session']; session = sessions[sid]
        content = contents[sid]; sha = digest(content)
        linked = datasets.get(session['published_dataset'])
        require(linked is not None, 'Published dataset link is absent: ' + sid)
        if sid in adopted:
            target = datasets[adopted[sid]]
        elif linked['sha'] == sha:
            target = linked
        else:
            # Never coalesce historical revisions by numerical equality or by
            # searching unrelated content. A new revision records this delivery.
            revision += 1
            identifier = 'recovered-' + digest([cid, sid, sha])
            require(not db.execute('SELECT 1 FROM datasets WHERE id=?', (identifier,)).fetchone(),
                    'Recovery dataset identifier is already occupied')
            target = dict(id=identifier, revision=revision, sha=sha, content=dumps(content))
            additions.append(target)
        targets[sid] = target['id']
        if target['id'] != session['published_dataset']:
            entry['sessions'].append(dict(session=sid, from_dataset=session['published_dataset'],
                                          to_dataset=target['id'], revision=target['revision'], sha256=sha))

    # Replay journal IDs, never display timestamps. Track both the original
    # storage pointer and the full-evidence pointer at each submission.
    current = recorded = None
    desired = {}
    for e in journal:
        p = e['payload']
        if e['action'] == 'imported':
            current = recorded = p['dataset']
        elif e['action'] == 'ingest_published':
            recorded = p['dataset']; current = targets[p['session']]
        elif e['action'] == ACTION:
            if p.get('current_dataset'):
                require(p['current_dataset'] in datasets, 'Recovery current dataset is absent')
                require(p['current_dataset'] == current, 'Recovery current input disagrees with publication order')
            recorded = current
        elif e['action'] == 'job_submitted' and p['job'] in jobs:
            job = jobs[p['job']]
            if job['state'] == 'queued':
                require(current is not None and p['dataset'] == recorded,
                        'Submission disagrees with publication context: ' + job['id'])
                desired[job['id']] = current
    require(current is not None, 'No unambiguous current input')
    final_keys = set()
    for jid, job in jobs.items():
        target = job['dataset']
        if job['state'] == 'queued':
            require(len(submissions.get(jid, [])) == 1, 'Missing or ambiguous queued submission: ' + jid)
            require(job['dataset'] == job_paths[jid], 'Unexplained queued job pointer: ' + jid)
            require(job['staged'] is None and job['published_run'] is None, 'Queued job already has a result: ' + jid)
            require(digest(loads(job['policy'])) == job['policy_sha'], 'Job policy fingerprint mismatch: ' + jid)
            target = desired[jid]
            if target != job['dataset']:
                entry['jobs'].append(dict(job=jid, from_dataset=job['dataset'], to_dataset=target))
        key = (target, job['policy_sha'], job['engine'])
        require(key not in final_keys, 'Recovery would collide with an existing job key')
        final_keys.add(key)
    entry['_additions'] = additions
    unfinished_preview = any(e['action'] == PREVIEW and (not completed or e['id'] > completed[-1]['id']) for e in journal)
    if entry['sessions'] or entry['jobs'] or unfinished_preview:
        entry.update(status='recoverable', current_dataset=current, version=VERSION)
    elif completed:
        # Keep the durable mappings visible on repeat, even after workers finish
        # their recovered jobs or an ordinary import advances the current study.
        entry.update({k: v for k, v in completed[-1]['payload'].items()
                      if k in ('sessions', 'jobs', 'current_dataset', 'version')})
        entry['status'] = 'already_recovered'


def plan(db):
    studies = []
    for campaign in rows(db, 'SELECT id FROM campaigns ORDER BY id'):
        cid = campaign['id']
        entry = dict(campaign=cid, status='unaffected', sessions=[], jobs=[],
                     runs=[dict(run=r['id'], dataset=r['dataset'], action='preserved') for r in rows(db, 'SELECT id,dataset FROM runs WHERE campaign=? ORDER BY id', (cid,))],
                     decisions=[dict(decision=d['id'], run=d['run'], action='preserved') for d in rows(db, 'SELECT id,run FROM decisions WHERE campaign=? ORDER BY id', (cid,))], unresolved=[])
        try:
            audit(db, entry)
        except (WorkbenchError, KeyError, TypeError, ValueError, IndexError, OverflowError) as exc:
            entry = {k: v for k, v in entry.items() if not k.startswith('_')}
            entry.update(status='blocked', sessions=[], jobs=[], unresolved=[dict(reason=str(exc))])
        studies.append(entry)
    return studies


def public(studies, mode, backup=None):
    return dict(version=VERSION, mode=mode, backup=str(backup) if backup else None,
                studies=[{k: v for k, v in entry.items() if not k.startswith('_')} for entry in studies])


def recover(path, dry_run=False, backup=None):
    path = Path(path).resolve()
    if not path.is_file():
        raise WorkbenchError('An existing database is required')
    db = sqlite3.connect(path.as_uri() + '?mode=' + ('ro' if dry_run else 'rw'), uri=True, isolation_level=None, timeout=30)
    db.row_factory = sqlite3.Row
    try:
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('BEGIN' if dry_run else 'BEGIN IMMEDIATE')
        studies = plan(db)
        if dry_run:
            db.rollback()
            return public(studies, 'dry_run')
        if backup is None:
            raise WorkbenchError('Apply requires a new backup destination')
        backup = Path(backup)
        if not backup.is_absolute():
            raise WorkbenchError('Backup destination must be absolute')
        if backup.is_symlink() or backup.exists():
            raise WorkbenchError('Choose a new backup destination')
        backup = backup.resolve()
        if backup == path:
            raise WorkbenchError('Choose a new backup destination')
        backup.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(backup, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(fd)
        # A separate reader snapshots committed data while we hold the writer
        # reservation. SQLite backup includes committed WAL pages as well.
        reader = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
        destination = sqlite3.connect(str(backup))
        try:
            reader.backup(destination)
        finally:
            destination.close()
            reader.close()
        for entry in studies:
            if entry['status'] != 'recoverable':
                continue
            cid = entry['campaign']
            for d in entry['_additions']:
                db.execute('INSERT INTO datasets VALUES (?,?,?,?,?,?)',
                           (d['id'], cid, d['revision'], d['sha'], d['content'], now()))
            for correction in entry['sessions']:
                db.execute('UPDATE ingest_sessions SET published_dataset=? WHERE id=?',
                           (correction['to_dataset'], correction['session']))
            # Free affected UNIQUE keys inside the transaction, allowing safe
            # permutations as well as simple moves. No temporary value commits.
            policies = {}
            for job in entry['jobs']:
                jid = job['job']
                policies[jid] = db.execute('SELECT policy_sha FROM jobs WHERE id=?', (jid,)).fetchone()[0]
                db.execute('UPDATE jobs SET policy_sha=? WHERE id=?', ('recovery-' + jid, jid))
            for job in entry['jobs']:
                db.execute("UPDATE jobs SET dataset=?,policy_sha=? WHERE id=? AND state='queued'",
                           (job['to_dataset'], policies[job['job']], job['job']))
            entry['status'] = 'recovered'
            event(db, cid, ACTION, {k: v for k, v in entry.items() if not k.startswith('_')})
        db.commit()
        return public(studies, 'apply', backup)
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()
