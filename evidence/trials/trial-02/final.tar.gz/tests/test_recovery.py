"""Recovery must prove provenance, preserve results, and commit atomically."""
from copy import deepcopy
import csv
import hashlib
import json
from pathlib import Path
import shutil
import sqlite3
import subprocess
import sys

import pytest

from truegate.codec import digest, dumps, loads
from truegate.database import transaction
from truegate.errors import WorkbenchError, Conflict
from truegate.ingestion import Ingestion
from truegate.jobs import Jobs
from truegate.recovery import recover, ACTION, PREVIEW
from truegate.repository import Repository, event, now
from truegate.reporting import export, verify, transfer_rows
from test_correction_lifecycle import evidence, correction, stage


def table(path, name):
    with sqlite3.connect(path) as db:
        return db.execute('SELECT * FROM ' + name + ' ORDER BY rowid').fetchall()


def suppressed(ingest, campaign, data, delivery, monkeypatch):
    """Reproduce the old projection-reuse bug through ordinary staging APIs."""
    revision = Repository(ingest.path).show(campaign)['current_revision']
    sid, _ = stage(ingest, campaign, data, delivery, revision)
    with monkeypatch.context() as patch:
        def reuse(db, cid, data):
            d = db.execute('SELECT * FROM datasets WHERE campaign=? ORDER BY revision DESC', (cid,)).fetchone()
            return dict(dataset=d['id'], revision=d['revision'], sha256=d['sha'], reused=True)
        patch.setattr('truegate.ingestion.store_dataset', reuse)
        ingest.publish(sid)
    return sid


def incident(path, monkeypatch, later=False):
    repo, ingest, jobs = Repository(path), Ingestion(path), Jobs(path)
    cid = repo.create('Independent history', 'screening')['campaign']
    initial, _ = stage(ingest, cid, evidence(), 'first', 0)
    first = ingest.publish(initial)['dataset']
    run = repo.run(cid)['run']
    repo.review(cid, run, 'accept', 'Scientist', 'Original inspected', 1)
    before = jobs.submit(cid, {'min_zprime': .41})['job']
    corrected = suppressed(ingest, cid, correction(evidence()), 'corrected', monkeypatch)
    after = jobs.submit(cid, {'min_zprime': .42})['job']
    staged = jobs.submit(cid, {'min_zprime': .43})['job']
    token = jobs.claim(staged, 'worker', 300)['token']
    jobs.compute(staged, token)
    latest = None
    if later:
        data = correction(evidence())
        data['records'][-1]['signal'] += 100
        sid, _ = stage(ingest, cid, data, 'latest', 1)
        latest = ingest.publish(sid)['dataset']
        newrun = repo.run(cid)['run']
        repo.review(cid, newrun, 'hold', 'Scientist', 'Latest inspected', 2)
    return dict(campaign=cid, initial=initial, corrected=corrected, first=first,
                before=before, after=after, staged=staged, token=token, run=run, latest=latest)


def test_recovery_submission_order_preservation_and_later_current(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    ids = incident(path, monkeypatch, later=True)
    repo, jobs = Repository(path), Jobs(path)
    cid = ids['campaign']
    review = repo.show(cid)['current_review']
    snapshot = repo.snapshot(cid, ids['run'])
    preserved = {t: table(path, t) for t in ['datasets', 'runs', 'decisions', 'events', 'ingest_sources', 'ingest_attempts', 'job_attempts']}
    with sqlite3.connect(path) as db:
        # Display timestamps intentionally contradict the journal.
        db.execute("UPDATE events SET created=printf('%08d',999999-id)")
        db.execute("UPDATE ingest_sources SET parsed='not JSON'")
    preserved['events'] = table(path, 'events')
    preserved['ingest_sources'] = table(path, 'ingest_sources')
    original = path.read_bytes()
    preview = recover(path, dry_run=True)
    assert path.read_bytes() == original
    entry = preview['studies'][0]
    assert entry['status'] == 'recoverable'
    assert len(entry['sessions']) == len(entry['jobs']) == 1
    assert entry['jobs'][0]['job'] == ids['after']
    assert entry['current_dataset'] == ids['latest']
    backup = tmp_path / 'backup.db'
    applied = recover(path, backup=backup)['studies'][0]
    assert applied == dict(entry, status='recovered')
    assert table(backup, 'datasets') == preserved['datasets']
    assert repo.snapshot(cid, ids['run']) == snapshot
    assert repo.show(cid)['current_review'] == review
    assert repo.show(cid)['current_revision'] == 3
    with sqlite3.connect(path) as db:
        for name, old in preserved.items():
            saved = table(path, name)
            assert saved[:len(old)] == old
        datasets = dict(db.execute('SELECT id,dataset FROM jobs'))
        assert datasets[ids['before']] == datasets[ids['staged']] == ids['first']
        assert datasets[ids['after']] == entry['sessions'][0]['to_dataset']
    assert repo.run(cid)['reused']
    jobs.publish(ids['staged'], ids['token'])
    newjob = jobs.submit(cid)['job']
    with sqlite3.connect(path) as db:
        assert db.execute('SELECT dataset FROM jobs WHERE id=?', (newjob,)).fetchone()[0] == ids['latest']
    # Repeating the current input is a no-op even though recovery allocated a
    # larger revision for an older delivery. New inputs use the next token.
    with sqlite3.connect(path) as db:
        latest = loads(db.execute('SELECT content FROM datasets WHERE id=?', (ids['latest'],)).fetchone()[0])
    assert repo.import_data(cid, latest)['reused']
    repeat = recover(path, backup=tmp_path / 'repeat-backup.db')['studies'][0]
    assert repeat['status'] == 'already_recovered'
    assert repeat['sessions'] == entry['sessions'] and repeat['jobs'] == entry['jobs']
    repo.review(cid, review['run'], 'accept', 'Scientist', 'Uses current token', 3)
    changed = deepcopy(latest); changed['records'][-1]['signal'] += 5
    assert repo.import_data(cid, changed)['revision'] == 4
    assert repo.show(cid)['current_review'] is None
    assert recover(path, dry_run=True)['studies'][0]['status'] == 'already_recovered'


@pytest.mark.parametrize('damage', ['missing_bytes', 'source_hash', 'manifest_hash', 'missing_source',
                                   'bad_json', 'unsupported_codec', 'missing_publication',
                                   'duplicate_publication', 'missing_submission', 'bad_preview', 'collision'])
def test_blocked_study_is_unchanged_and_other_studies_proceed(tmp_path, monkeypatch, damage):
    path = tmp_path / 'study.db'
    bad = incident(path, monkeypatch)
    good = incident(path, monkeypatch)
    with transaction(path) as db:
        sid = bad['corrected']; cid = bad['campaign']
        if damage == 'missing_bytes':
            db.execute("UPDATE ingest_sources SET raw=NULL WHERE session=? AND source_id='transfer_history'", (sid,))
        elif damage == 'source_hash':
            db.execute("UPDATE ingest_sources SET sha=? WHERE session=?", ('0'*64, sid))
        elif damage == 'manifest_hash':
            db.execute('UPDATE ingest_sessions SET manifest_sha=? WHERE id=?', ('0'*64, sid))
        elif damage == 'missing_source':
            db.execute('DELETE FROM ingest_attempts WHERE session=?', (sid,))
            db.execute('DELETE FROM ingest_sources WHERE session=?', (sid,))
        elif damage in ('bad_json', 'unsupported_codec'):
            s = db.execute('SELECT manifest FROM ingest_sessions WHERE id=?', (sid,)).fetchone()
            m = loads(s['manifest'])
            spec = next(s for s in m['sources'] if s['kind'] == 'transfer_history')
            if damage == 'unsupported_codec':
                spec['codec'] = 'unknown/99'
            else:
                raw = b'{"bindings": null}'
                spec['sha256'] = hashlib.sha256(raw).hexdigest()
                db.execute('UPDATE ingest_sources SET raw=?,sha=? WHERE session=? AND source_id=?',
                           (raw, spec['sha256'], sid, spec['id']))
            db.execute('UPDATE ingest_sessions SET manifest=?,manifest_sha=? WHERE id=?', (dumps(m), digest(m), sid))
        elif damage in ('missing_publication', 'duplicate_publication'):
            e = next(e for e in db.execute("SELECT * FROM events WHERE campaign=? AND action='ingest_published'", (cid,)) if loads(e['payload'])['session'] == sid)
            if damage == 'missing_publication':
                db.execute('DELETE FROM events WHERE id=?', (e['id'],))
            else:
                event(db, cid, 'ingest_published', loads(e['payload']))
        elif damage == 'missing_submission':
            db.execute("DELETE FROM events WHERE action='job_submitted' AND json_extract(payload,'$.job')=?", (bad['after'],))
        elif damage == 'bad_preview':
            event(db, cid, PREVIEW, dict(version='transfer-evidence-preview-0', jobs=[], sessions=[dict(
                session=sid, from_dataset=bad['first'], to_dataset=bad['first'], sha256='0'*64)]))
        else:
            # A valid partial migration moved one job to a verified revision;
            # reconciling another would collide with that job's final key.
            target = 'collision-dataset'
            from truegate.ingest_resolution import assemble
            manifest = loads(db.execute('SELECT manifest FROM ingest_sessions WHERE id=?', (sid,)).fetchone()[0])
            content = assemble(manifest, db.execute('SELECT * FROM ingest_sources WHERE session=?', (sid,)).fetchall())
            db.execute('INSERT INTO datasets VALUES (?,?,?,?,?,?)',
                       (target, cid, 2, digest(content), dumps(content), now()))
            job = db.execute('SELECT * FROM jobs WHERE id=?', (bad['after'],)).fetchone()
            db.execute('UPDATE jobs SET dataset=?,policy_sha=?,policy=? WHERE id=?',
                       (target, job['policy_sha'], job['policy'], bad['before']))
            event(db, cid, PREVIEW, dict(version='transfer-evidence-preview-0', sessions=[dict(
                session=sid, from_dataset=bad['first'], to_dataset=target, sha256=digest(content))], jobs=[dict(
                job=bad['before'], from_dataset=bad['first'], to_dataset=target)]))
            # Force both queued submissions to the corrected-publication context.
            before_event = db.execute("SELECT id FROM events WHERE action='job_submitted' AND json_extract(payload,'$.job')=?", (bad['before'],)).fetchone()[0]
            publication = db.execute("SELECT id,payload FROM events WHERE action='ingest_published' AND json_extract(payload,'$.session')=?", (sid,)).fetchone()
            # Move publication earlier by swapping its ID with the before submission.
            db.execute('UPDATE events SET id=-1 WHERE id=?', (publication['id'],))
            db.execute('UPDATE events SET id=? WHERE id=?', (publication['id'], before_event))
            db.execute('UPDATE events SET id=? WHERE id=-1', (before_event,))
    before = {t: table(path, t) for t in ['datasets', 'events', 'jobs', 'ingest_sessions']}
    preview = recover(path, dry_run=True)
    entries = {s['campaign']: s for s in preview['studies']}
    assert entries[bad['campaign']]['status'] == 'blocked'
    assert entries[bad['campaign']]['sessions'] == entries[bad['campaign']]['jobs'] == []
    if damage == 'collision':
        assert 'collide' in entries[bad['campaign']]['unresolved'][0]['reason']
    assert entries[good['campaign']]['status'] == 'recoverable'
    recover(path, backup=tmp_path / 'backup.db')
    for name, old in before.items():
        with sqlite3.connect(path) as db:
            columns = [r[1] for r in db.execute('PRAGMA table_info(' + name + ')')]
        campaign_index = columns.index('campaign')
        assert [r for r in table(path, name) if r[campaign_index] == bad['campaign']] == [r for r in old if r[campaign_index] == bad['campaign']]


def test_apply_rolls_back_all_studies_on_unexpected_failure(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    incident(path, monkeypatch)
    incident(path, monkeypatch)
    old = {t: table(path, t) for t in ['datasets', 'ingest_sessions', 'jobs', 'events']}
    calls = []
    from truegate import recovery
    original = recovery.event
    def fail(db, cid, action, payload):
        calls.append(cid)
        original(db, cid, action, payload)
        if len(calls) == 2:
            raise RuntimeError('injected failure after writes')
    monkeypatch.setattr(recovery, 'event', fail)
    backup = tmp_path / 'backup.db'
    with pytest.raises(RuntimeError, match='injected'):
        recover(path, backup=backup)
    for name, content in old.items():
        assert table(path, name) == table(backup, name) == content


@pytest.mark.parametrize('destination', ['existing', 'same', 'hardlink', 'symlink', 'relative', 'missing'])
def test_backup_must_be_new_and_independent(tmp_path, monkeypatch, destination):
    path = tmp_path / 'study.db'
    incident(path, monkeypatch)
    backup = tmp_path / 'backup.db'
    if destination == 'existing':
        backup.write_bytes(b'do not overwrite')
    elif destination == 'same':
        backup = path
    elif destination == 'hardlink':
        backup.hardlink_to(path)
    elif destination == 'symlink':
        backup.symlink_to(path)
    elif destination == 'relative':
        backup = Path('relative-backup.db')
    elif destination == 'missing':
        backup = None
    before = path.read_bytes()
    with pytest.raises(WorkbenchError):
        recover(path, backup=backup)
    assert path.read_bytes() == before


def test_report_keeps_equal_dose_wells(tmp_path):
    from truegate.engine import analyze
    analysis = analyze(evidence())
    rows = transfer_rows(analysis)
    assert len(rows) == 2
    assert {r['record_id'] for r in rows} == {'early', 'late'}
    repo = Repository(tmp_path / 'study.db')
    cid = repo.create('Distinct wells', 'screening')['campaign']
    repo.import_data(cid, evidence())
    run = repo.run(cid)['run']
    export(repo.snapshot(cid, run), tmp_path / 'report')
    with (tmp_path / 'report' / 'transfer-bindings.csv').open() as stream:
        assert len(list(csv.DictReader(stream))) == 2
    assert verify(tmp_path / 'report')['verified']


def test_supplied_incident_cli_and_preview_adoption(tmp_path):
    source = Path(__file__).resolve().parents[1] / 'examples/recovery-incident/study.db'
    path = tmp_path / 'study.db'
    shutil.copyfile(source, path)
    original = {t: table(path, t) for t in ['runs', 'decisions', 'ingest_sources', 'ingest_attempts', 'job_attempts']}
    def cli(*args):
        result = subprocess.run([sys.executable, '-m', 'truegate.cli', 'evidence-recover', '--db', str(path), *args],
                                capture_output=True, text=True, check=True)
        return json.loads(result.stdout)
    preview = cli('--dry-run')
    assert len([s for s in preview['studies'] if s['status'] == 'recoverable']) == 18
    applied = cli('--backup', str(tmp_path / 'backup.db'))
    assert [dict(s, status='recoverable') if s['status'] == 'recovered' else s for s in applied['studies']] == preview['studies']
    repeated = cli('--backup', str(tmp_path / 'backup2.db'))
    assert len([s for s in repeated['studies'] if s['status'] == 'already_recovered']) == 18
    for name, contents in original.items():
        assert table(path, name) == contents
    with sqlite3.connect(path) as db:
        for cid, in db.execute("SELECT id FROM campaigns WHERE name IN ('Screening study 7138','Screening study 7139')"):
            assert db.execute('SELECT COUNT(*) FROM datasets WHERE campaign=?', (cid,)).fetchone()[0] == 3
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert db.execute('PRAGMA foreign_key_check').fetchall() == []


def test_codec_selection_applies_to_staging_and_publication(tmp_path):
    from truegate.instrument_files import parse, HEADERS
    import io
    repo, ingest = Repository(tmp_path / 'codec.db'), Ingestion(tmp_path / 'codec.db')
    cid = repo.create('Legacy boundary', 'screening')['campaign']
    data = evidence()
    model = deepcopy(data['transfer_history'])
    for binding in model['bindings']:
        binding['sequence'] += 1
    stream = io.StringIO(newline='')
    writer = csv.DictWriter(stream, fieldnames=HEADERS['readings'])
    writer.writeheader()
    writer.writerows(dict(r, revision=1) for r in data['records'])
    sources = {'readings': stream.getvalue().encode(), 'transfer_history': dumps(model).encode()}
    manifest = dict(delivery_id='legacy', expected_revision=0, sources=[
        dict(id=k, kind=k, sha256=hashlib.sha256(raw).hexdigest(),
             **({'codec': 'transfer-history/1'} if k == 'transfer_history' else {}))
        for k, raw in sources.items()])
    sid = ingest.open(cid, manifest)['session']
    for k, raw in sources.items():
        assert ingest.add(sid, k, raw)['state'] == 'accepted'
    preview = ingest.preview(sid)
    assert preview['input']['transfer_history'] == data['transfer_history']
    assert preview['input']['ingestion']['sources'][1]['text'] == dumps(model)
    ingest.publish(sid)
    assert recover(repo.path, dry_run=True)['studies'][0]['status'] == 'unaffected'
    model['bindings'][0]['sequence'] = True
    assert parse(dumps(model).encode(), 'transfer_history', 'transfer-history/1')[1]


def test_backup_captures_committed_wal_and_no_change_apply(tmp_path):
    path = tmp_path / 'wal.db'
    repo = Repository(path)
    # Keep a WAL connection alive so the backup must incorporate WAL pages.
    with sqlite3.connect(path) as writer:
        writer.execute('PRAGMA journal_mode=WAL')
        cid = repo.create('No retained delivery', 'screening')['campaign']
        repo.import_data(cid, evidence())
        backup = tmp_path / 'backup.db'
        result = recover(path, backup=backup)
        assert result['studies'][0]['status'] == 'unaffected'
        standalone = tmp_path / 'standalone.db'
        shutil.copyfile(backup, standalone)
        assert table(standalone, 'datasets') == table(path, 'datasets')
        assert Repository(standalone).show(cid)['current_revision'] == 1


def test_recovery_does_not_rewrite_later_normal_publications(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    ids = incident(path, monkeypatch)
    first = recover(path, backup=tmp_path / 'backup.db')['studies'][0]
    repo, ingest = Repository(path), Ingestion(path)
    cid = ids['campaign']
    assert repo.show(cid)['current_review'] is None
    data = evidence(); data['records'][-1]['signal'] += 50
    sid, _ = stage(ingest, cid, data, 'newer', 2)
    new = ingest.publish(sid)
    assert new['revision'] == 3
    result = recover(path, dry_run=True)['studies'][0]
    assert result['status'] == 'already_recovered' and result['sessions'] == first['sessions']
    run = repo.run(cid)['run']
    assert repo.snapshot(cid, run)['dataset_revision'] == 3
    # Another legacy discrepancy can be reconciled without duplicating old moves.
    suppressed(ingest, cid, correction(data), 'another-correction', monkeypatch)
    result = recover(path, backup=tmp_path / 'backup2.db')['studies'][0]
    assert result['status'] == 'recovered' and len(result['sessions']) == 1
    assert result['sessions'][0]['revision'] == 4
    assert recover(path, dry_run=True)['studies'][0]['status'] == 'already_recovered'


def test_completed_ledger_without_explicit_current_pointer(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    ids = incident(path, monkeypatch, later=True)
    recover(path, backup=tmp_path / 'backup.db')
    # Simulate the documented older ledger format; the latest publication is
    # revision 2 even though historical recovery allocated revision 3.
    with transaction(path) as db:
        e = db.execute('SELECT id,payload FROM events WHERE action=?', (ACTION,)).fetchone()
        payload = loads(e['payload']); del payload['current_dataset']
        db.execute('UPDATE events SET payload=? WHERE id=?', (dumps(payload), e['id']))
    repo = Repository(path)
    assert repo.show(ids['campaign'])['current_review']['action'] == 'hold'
    jobs = Jobs(path)
    jobs.submit(ids['campaign'], {'min_zprime': .49})
    assert recover(path, dry_run=True)['studies'][0]['status'] == 'already_recovered'
