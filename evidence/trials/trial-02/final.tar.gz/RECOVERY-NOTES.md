# Transfer evidence repair and recovery

The live workflow now distinguishes complete evidence from its numerical projection. `store_dataset` formerly reused a dataset when concentrations and responses matched, even when delivered volumes, operation revisions, ancestry, or original instrument bytes differed. It now reuses only the exact current input fingerprint. Job submission now includes the dataset in its reuse key. Reports retain every transfer binding, including distinct wells with the same compound and dose.

Instrument staging and complete-delivery assembly both honor the source descriptor's codec. `transfer-history/1` uses an exclusive boundary, converted to the inclusive snapshot convention by subtracting one; the original manifest and bytes remain unchanged. Unsupported formats and malformed boundaries are rejected. Complete publication validates bindings against actual samples and checks retained source fingerprints. Parsed caches are not authoritative. The existing overdraw, lease fencing, and historical snapshot behavior remains intact.

## Recovery behavior

`evidence-recover` reconstructs published deliveries from accepted original bytes, verifies manifest/source/dataset fingerprints and publication provenance, and uses journal IDs to determine submission context. It appends missing immutable inputs, adopts independently verified preview revisions, repairs publication links, and moves queued jobs to the input available at submission. Completed and running work retains its inputs. Existing datasets, sources, attempts, runs, review decisions, and journal entries remain unchanged.

The entire study is blocked if retained evidence is missing, contradictory, unsupported, or would produce conflicting job keys. Valid unrelated studies still proceed. Apply obtains a writer reservation, creates an independent SQLite backup (including committed WAL data), and commits all admitted studies together. Unexpected failures roll back the apply. Each reconciled study gets one completed recovery event; repeats report its mappings without duplicating changes. Dry-run writes neither the database nor a backup.

Recovered historical datasets can have revision numbers greater than the current input. The recovery event records the current dataset; ordinary later imports advance it. `show.current_revision` remains the maximum allocated revision and is the optimistic concurrency token for review and ingestion. A historical report continues to show its own dataset revision. Recovery never transfers an earlier acceptance to changed evidence.

## Reproduction and executed report

Run from `/workspace`, choosing a destination that does not exist:

```sh
PYTHONPATH=src python scripts/recover_incident.py /workspace/new-recovery-report
```

The script copies the supplied incident using SQLite backup, executes the documented CLI for preview, apply, and a second apply with another backup, and verifies preservation and integrity. No network is used. The supplied database is opened read-only and its file hash is checked afterward.

The executed artifacts are in [recovery-report](recovery-report/):

- [preview.json](recovery-report/preview.json), [apply.json](recovery-report/apply.json), and [repeat.json](recovery-report/repeat.json) contain complete session/job mappings and preserved run/decision identifiers.
- [validation.json](recovery-report/validation.json) includes study names, source fingerprint, counts, and integrity checks.
- `study.db` is the recovered copy; `backup.db` is the pre-change backup; `repeat-backup.db` is the backup taken before the no-change repeat.
- [partial-consistency.json](recovery-report/partial-consistency.json) records the supplied partial checker's output.

Executed result: **18 recovered, 12 unaffected, 10 blocked**. Recovery appended **20 datasets**, changed **24 session links** and **24 queued job links**, and appended **18 recovery events**. Four session links adopted existing preview revisions, so those inputs were not duplicated. All **58 original datasets**, **616 original events**, **40 runs**, **40 decisions**, **100 job attempts**, **160 source records**, and **160 source attempts** were preserved. SQLite integrity and foreign-key checks passed. The second apply reported all 18 reconciled studies as `already_recovered` and added no datasets, moves, or events.

The supplied partial checker reports **zero violations and 14 unresolved studies**. Ten are the blocked studies below. The other four (7100, 7103, 7110, 7126) have later direct imports, which that checker deliberately declines to inspect. Recovery verifies their import journal records and fingerprints, preserves those later inputs as current, and reconstructs only the earlier retained corrections. Studies 7134 and 7137 similarly retain later valid instrument publications as current. Studies 7138 and 7139 adopt the two verifiable preview datasets apiece and restore waiting jobs to their individual submission contexts.

## Blocked evidence

No changes were applied to these studies. Full campaign and affected record IDs are in `validation.json`; missing submission IDs are also listed here.

| Study | Evidence preventing recovery | Required evidence to proceed |
| --- | --- | --- |
| 7102 | Corrected delivery's `history` source bytes are absent | Original bytes matching the retained source and manifest digests |
| 7104 | Corrected delivery's `history` source bytes are absent | Original bytes matching the retained source and manifest digests |
| 7118 | Corrected delivery's `history` source bytes are absent | Original bytes matching the retained source and manifest digests |
| 7122 | Corrected delivery's `history` source bytes are absent | Original bytes matching the retained source and manifest digests |
| 7108 | No submission event for queued job `3c5336b236264c3a93e44b929f5ca658` | Authoritative submission provenance establishing its journal context |
| 7109 | No submission event for queued job `20650986a07c4e9e93794377e3aa0d84` | Authoritative submission provenance establishing its journal context |
| 7112 | No submission event for queued job `735e3506954c4ef08c911228fda426fe` | Authoritative submission provenance establishing its journal context |
| 7123 | No submission event for queued job `7c7cd9abc0ed4aa5939bfb65181450c7` | Authoritative submission provenance establishing its journal context |
| 7133 | Corrected history declares `transfer-history/unknown` | An authoritative format specification and validated decoder |
| 7135 | Corrected history declares `transfer-history/unknown` | An authoritative format specification and validated decoder |

Parsed caches cannot replace missing source bytes. Display timestamps cannot establish missing submission order. An unknown codec cannot safely be interpreted as either supported binding convention. Recovery leaves these studies intact rather than inventing provenance.

## Regression validation

```sh
PYTHONPATH=src python -m pytest -q --basetemp=/workspace/.pytest-tmp
```

Validation completed with **68 passing tests**. The regression suite covers evidence-only corrections in flat and campaign inputs; pinned jobs and historical exports; equal-dose report wells; codec-aware staging; stale parsed caches; journal order despite contradictory display timestamps; preview-ledger adoption; malformed/missing evidence; job-key collisions; isolation of blocked studies; full apply rollback; backup alias rejection and committed WAL contents; current-input selection after historical reconstruction; monotonic revision tokens; repeated recovery and later ordinary publications; and compatibility with completed ledgers that omit an explicit current pointer.
