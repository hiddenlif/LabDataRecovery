#!/usr/bin/env python3
"""Run the documented recovery CLI on a new copy and record preservation checks.

Usage: PYTHONPATH=src python scripts/recover_incident.py /workspace/new-report
The destination must not exist. The supplied incident is opened read-only.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys

ROOT = Path(__file__).resolve().parents[1]
SOURCE = ROOT / 'examples/recovery-incident/study.db'


def read_table(path, name):
    with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as db:
        return db.execute('SELECT * FROM ' + name + ' ORDER BY rowid').fetchall()


def write(path, value):
    path.write_text(json.dumps(value, indent=2, sort_keys=True) + '\n')


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', type=Path)
    out = parser.parse_args().destination.resolve()
    out.mkdir(parents=True, exist_ok=False)
    source_sha = hashlib.sha256(SOURCE.read_bytes()).hexdigest()
    path = out / 'study.db'
    with sqlite3.connect(SOURCE.as_uri() + '?mode=ro', uri=True) as original, sqlite3.connect(path) as copy:
        original.backup(copy)

    def cli(name, *args):
        result = subprocess.run([sys.executable, '-m', 'truegate.cli', 'evidence-recover',
                                 '--db', str(path), *args], cwd=ROOT, text=True, capture_output=True, check=True)
        report = json.loads(result.stdout)
        write(out / (name + '.json'), report)
        return report

    preview = cli('preview', '--dry-run')
    applied = cli('apply', '--backup', str(out / 'backup.db'))
    after_apply = {name: read_table(path, name) for name in ('datasets', 'events', 'jobs', 'ingest_sessions')}
    repeat = cli('repeat', '--backup', str(out / 'repeat-backup.db'))
    for name, contents in after_apply.items():
        assert read_table(path, name) == contents, 'Repeat changed ' + name
    expected = [dict(s, status='recoverable') if s['status'] == 'recovered' else s for s in applied['studies']]
    assert preview['studies'] == expected
    assert repeat['studies'] == [dict(s, status='already_recovered') if s['status'] == 'recovered' else s for s in applied['studies']]
    preserved = {}
    for name in ('runs', 'decisions', 'job_attempts', 'ingest_sources', 'ingest_attempts'):
        before, after = read_table(out / 'backup.db', name), read_table(path, name)
        assert before == after, name
        preserved[name] = len(before)
    for name in ('datasets', 'events'):
        before, after = read_table(out / 'backup.db', name), read_table(path, name)
        assert before == after[:len(before)], name
        preserved[name] = dict(original=len(before), appended=len(after) - len(before))
    assert hashlib.sha256(SOURCE.read_bytes()).hexdigest() == source_sha
    with sqlite3.connect(path) as db:
        assert db.execute('PRAGMA integrity_check').fetchone()[0] == 'ok'
        assert db.execute('PRAGMA foreign_key_check').fetchall() == []
        names = dict(db.execute('SELECT id,name FROM campaigns'))
    diagnostic = subprocess.run([sys.executable, str(ROOT / 'examples/recovery-incident/check_consistency.py'), str(path)],
                                cwd=ROOT, capture_output=True, text=True)
    diagnostic_report = json.loads(diagnostic.stdout)
    write(out / 'partial-consistency.json', diagnostic_report)
    blocked = {s['campaign'] for s in applied['studies'] if s['status'] == 'blocked'}
    for name in ('datasets', 'events', 'jobs', 'ingest_sessions'):
        with sqlite3.connect(path) as db:
            columns = [r[1] for r in db.execute('PRAGMA table_info(' + name + ')')]
        index = columns.index('campaign')
        before = read_table(out / 'backup.db', name)
        after = read_table(path, name)
        assert [r for r in before if r[index] in blocked] == [r for r in after if r[index] in blocked], name
    # This intentionally partial checker ignores submission provenance when
    # judging waiting jobs and treats later direct imports as unresolved.
    assert all(v['campaign'] in blocked for v in diagnostic_report['violations'])
    summary = dict(source=str(SOURCE.relative_to(ROOT)), source_sha256=source_sha,
                   status_counts=dict(Counter(s['status'] for s in applied['studies'])),
                   preserved=preserved, integrity_check='ok', foreign_key_check=[],
                   studies=[dict(name=names[s['campaign']], **s) for s in applied['studies']],
                   partial_checker_exit=diagnostic.returncode)
    write(out / 'validation.json', summary)
    print(json.dumps(dict(directory=str(out), status_counts=summary['status_counts'], preserved=preserved), indent=2))


if __name__ == '__main__':
    main()
