#!/usr/bin/env python3
"""Run the documented migration on a fresh incident copy and retain its reports.

Usage: PYTHONPATH=src python scripts/recover_incident.py /workspace/recovery-artifacts
The destination must be new. The supplied incident database is opened read-only.
"""
import argparse
from collections import Counter
import hashlib
import json
from pathlib import Path
import sqlite3
import subprocess
import sys

from truegate.repository import Repository
from truegate.reporting import export, verify

ROOT = Path(__file__).resolve().parents[1]


def snapshot(path):
    with sqlite3.connect(path.as_uri() + '?mode=ro', uri=True) as db:
        db.row_factory = sqlite3.Row
        return {name: [dict(r) for r in db.execute(f'SELECT * FROM {name} ORDER BY rowid')]
                for name, in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument('destination', type=Path)
    args = parser.parse_args()
    out = args.destination.resolve()
    if not out.is_relative_to(ROOT):
        parser.error('Keep migration artifacts in this checkout')
    out.mkdir(parents=True, exist_ok=False)
    supplied = ROOT / 'examples/recovery-incident/study.db'
    fingerprint = hashlib.sha256(supplied.read_bytes()).hexdigest()
    path = out / 'study.db'
    reader = sqlite3.connect(supplied.as_uri() + '?mode=ro', uri=True)
    destination = sqlite3.connect(path)
    try:
        reader.backup(destination)
    finally:
        destination.close(); reader.close()
    before = snapshot(path)

    def cli(filename, *options):
        result = subprocess.run([sys.executable, '-m', 'truegate.cli', 'evidence-recover',
                                 '--db', str(path), *map(str, options)],
                                cwd=ROOT, text=True, capture_output=True, check=True)
        report = json.loads(result.stdout)
        (out / filename).write_text(json.dumps(report, indent=2) + '\n')
        return report

    preview = cli('preview.json', '--dry-run')
    assert snapshot(path) == before
    applied = cli('apply.json', '--backup', out / 'before.db')
    assert snapshot(out / 'before.db') == before
    after = snapshot(path)
    for table in ['runs', 'decisions', 'ingest_sources', 'ingest_attempts', 'job_attempts', 'campaigns']:
        assert after[table] == before[table], table
    for table in ['datasets', 'events']:
        assert after[table][:len(before[table])] == before[table], table
    for table, field, changes, identity in [('jobs', 'dataset', 'jobs', 'job'),
                                           ('ingest_sessions', 'published_dataset', 'sessions', 'session')]:
        moves = {m[identity]: m['to_dataset'] for s in applied['studies'] for m in s[changes]}
        expected = [dict(row, **{field: moves[row['id']]}) if row['id'] in moves else row
                    for row in before[table]]
        assert after[table] == expected, table
    for p, a in zip(preview['studies'], applied['studies']):
        assert dict(p, status='recovered') == a if p['status'] == 'recoverable' else p == a
    repeat = cli('repeat.json', '--backup', out / 'repeat-before.db')
    assert snapshot(path) == after == snapshot(out / 'repeat-before.db')
    assert all(s['status'] != 'recovered' for s in repeat['studies'])
    diagnostics = subprocess.run([sys.executable, str(ROOT / 'examples/recovery-incident/check_consistency.py'), str(path)],
                                 cwd=ROOT, text=True, capture_output=True)
    diagnostics.check_returncode() if diagnostics.returncode not in (0, 1) else None
    consistency = json.loads(diagnostics.stdout)
    (out / 'consistency.json').write_text(json.dumps(consistency, indent=2) + '\n')
    blocked = {s['campaign'] for s in applied['studies'] if s['status'] == 'blocked'}
    assert all(v['campaign'] in blocked for v in consistency['violations'])
    recovered = next(s for s in applied['studies'] if s['status'] == 'recovered' and s['runs'])
    repo = Repository(path)
    export(repo.snapshot(recovered['campaign'], recovered['runs'][0]['run']), out / 'historical-report')
    assert verify(out / 'historical-report')['verified']
    assert hashlib.sha256(supplied.read_bytes()).hexdigest() == fingerprint
    summary = dict(statuses=dict(Counter(s['status'] for s in applied['studies'])),
                   appended_datasets=len(after['datasets']) - len(before['datasets']),
                   session_mappings=sum(len(s['sessions']) for s in applied['studies']),
                   job_moves=sum(len(s['jobs']) for s in applied['studies']),
                   preserved_runs=len(before['runs']), preserved_decisions=len(before['decisions']),
                   preserved_job_attempts=len(before['job_attempts']),
                   source_sha256=fingerprint, preservation_verified=True,
                   repeat_verified=True, backup_verified=True,
                   partial_diagnostic_violations=len(consistency['violations']),
                   partial_diagnostic_unresolved=len(consistency['unresolved']))
    (out / 'summary.json').write_text(json.dumps(summary, indent=2) + '\n')
    print(json.dumps(summary, indent=2))


if __name__ == '__main__':
    main()
