"""Reconcile retained deliveries without rewriting historical scientific evidence.

Planning is read-only and study-local. Applying a plan holds one writer reservation
through the independent SQLite backup and the atomic mutation of all admitted studies.
"""
import os
from pathlib import Path
import sqlite3
import uuid

from .codec import loads, dumps, digest
from .errors import WorkbenchError
from .ingest_resolution import assemble
from .ingestion import manifest_contract
from .repository import event, now

VERSION = 'transfer-evidence-v1'
ACTION = 'transfer_evidence_recovered_v1'
PREVIEW = 'transfer_evidence_recovered_preview'


def rows(db, query, args=()):
    return [dict(row) for row in db.execute(query, args)]


def require(condition, reason):
    if not condition:
        raise WorkbenchError(reason)


def study_plan(db, cid):
    entry = dict(campaign=cid, status='unaffected', sessions=[], jobs=[],
                 runs=[], decisions=[], unresolved=[])
    journal = rows(db, 'SELECT * FROM events WHERE campaign=? ORDER BY id', (cid,))
    for item in journal:
        item['payload'] = loads(item['payload'])
        require(isinstance(item['payload'], dict), 'Journal payload is not an object')
    completed = [e for e in journal if e['action'] == ACTION]
    if completed:
        # Later ordinary imports remain authoritative in repository.latest_dataset.
        # Keep the durable mappings, including their original from_dataset values.
        saved = completed[-1]['payload']
        require(saved.get('version', VERSION) == VERSION and saved.get('campaign') == cid,
                'Invalid completed recovery record')
        return dict(saved, status='already_recovered')

    sessions = {s['id']: s for s in rows(db, "SELECT * FROM ingest_sessions WHERE campaign=? AND state='published'", (cid,))}
    publications = [e for e in journal if e['action'] == 'ingest_published']
    previews = [e for e in journal if e['action'] == PREVIEW]
    if not sessions and not publications and not previews:
        return entry
    datasets = {d['id']: d for d in rows(db, 'SELECT * FROM datasets WHERE campaign=?', (cid,))}
    jobs = {j['id']: j for j in rows(db, 'SELECT * FROM jobs WHERE campaign=?', (cid,))}

    def dataset(identifier):
        require(identifier in datasets, 'Dataset reference is absent or belongs to another study: ' + str(identifier))
        d = datasets[identifier]
        require(digest(loads(d['content'])) == d['sha'], 'Stored dataset fingerprint mismatch: ' + identifier)
        return d

    # No row is accepted as provenance merely because its hash resembles a delivery.
    imported = {}
    for e in journal:
        if e['action'] == 'imported':
            p = e['payload']
            d = dataset(p['dataset'])
            require(p['revision'] == d['revision'] and p['sha256'] == d['sha'],
                    'Import journal disagrees with dataset: ' + d['id'])
            require(d['id'] not in imported, 'Duplicate import provenance: ' + d['id'])
            imported[d['id']] = e['id']

    publication_by_session = {}
    contents = {}
    for e in publications:
        p = e['payload']
        sid = p['session']
        require(sid in sessions and sid not in publication_by_session,
                'Missing or ambiguous publication session: ' + str(sid))
        session = sessions[sid]
        dataset(p['dataset'])
        dataset(session['published_dataset'])
        manifest = loads(session['manifest'])
        require(digest(manifest) == session['manifest_sha'], 'Manifest fingerprint mismatch: ' + sid)
        manifest_contract(manifest)
        require(manifest['delivery_id'] == session['delivery_key'] and
                manifest['expected_revision'] == session['expected_revision'],
                'Manifest disagrees with session: ' + sid)
        opened = [x for x in journal if x['action'] == 'ingest_opened' and x['payload'].get('session') == sid]
        require(len(opened) == 1 and opened[0]['id'] < e['id'] and
                opened[0]['payload'].get('manifest_sha256') == session['manifest_sha'],
                'Missing or inconsistent opening provenance: ' + sid)
        sources = rows(db, 'SELECT * FROM ingest_sources WHERE session=?', (sid,))
        require({s['source_id'] for s in sources} == {s['id'] for s in manifest['sources']},
                'Retained source set differs from manifest: ' + sid)
        require(all(isinstance(s['raw'], bytes) for s in sources), 'Missing original source bytes: ' + sid)
        contents[sid] = assemble(manifest, sources)
        publication_by_session[sid] = e
    require(set(publication_by_session) == set(sessions), 'Published session lacks a publication event')

    adopted = {}
    moved = {}
    for e in previews:
        p = e['payload']
        require(p.get('version') == 'transfer-evidence-preview-0', 'Unsupported partial recovery ledger')
        for mapping in p['sessions']:
            sid = mapping['session']
            require(sid in sessions and sid not in adopted, 'Ambiguous partial recovery session')
            original = publication_by_session[sid]
            d = dataset(mapping['to_dataset'])
            require(original['id'] < e['id'] and mapping['from_dataset'] == original['payload']['dataset'] and
                    mapping['sha256'] == d['sha'] == digest(contents[sid]),
                    'Partial recovery evidence does not match retained delivery: ' + sid)
            adopted[sid] = mapping
        for mapping in p['jobs']:
            jid = mapping['job']
            require(jid in jobs and jid not in moved, 'Ambiguous partial recovery job')
            dataset(mapping['from_dataset']); dataset(mapping['to_dataset'])
            require(mapping['to_dataset'] in {m['to_dataset'] for m in adopted.values()},
                    'Partial recovery job targets unverified evidence')
            require(jobs[jid]['dataset'] == mapping['to_dataset'], 'Partial recovery job pointer mismatch: ' + jid)
            moved[jid] = mapping

    authorized = set(imported) | {m['to_dataset'] for m in adopted.values()}
    require(set(datasets) <= authorized, 'Dataset has no verifiable import or recovery provenance')
    revision = max((d['revision'] for d in datasets.values()), default=0)
    targets = {}
    additions = []
    for e in publications:
        sid = e['payload']['session']
        session = sessions[sid]
        source = e['payload']['dataset']
        require(session['published_dataset'] in {source, adopted.get(sid, {}).get('to_dataset')},
                'Publication pointer changed without recovery provenance: ' + sid)
        content = contents[sid]
        sha = digest(content)
        linked = dataset(session['published_dataset'])
        if sid in adopted:
            target = dataset(adopted[sid]['to_dataset'])
        elif linked['sha'] == sha:
            target = linked
        else:
            matches = [d for d in datasets.values() if d['sha'] == sha]
            require(len(matches) <= 1, 'Multiple matching revisions have ambiguous provenance: ' + sid)
            if matches:
                target = dataset(matches[0]['id'])
            else:
                revision += 1
                # Stable proposed IDs make preview/apply comparable; preview reserves nothing.
                identifier = 'recovered-' + digest({'campaign': cid, 'session': sid, 'sha256': sha})
                require(not db.execute('SELECT 1 FROM datasets WHERE id=?', (identifier,)).fetchone(),
                        'Proposed recovery identifier already exists')
                target = dict(id=identifier, revision=revision, sha=sha)
                additions.append(dict(target, content=content))
        targets[sid] = target['id']
        if session['published_dataset'] != target['id'] or sid in adopted:
            entry['sessions'].append(dict(session=sid, from_dataset=session['published_dataset'],
                                          to_dataset=target['id'], revision=target['revision'], sha256=sha))

    # Replay both the historical storage pointer and the recovered scientific input.
    # Timestamps and revision allocation order are deliberately not consulted.
    current, original_current = None, None
    submissions = {}
    for e in journal:
        p = e['payload']
        if e['action'] == 'imported':
            current = original_current = p['dataset']
        elif e['action'] == 'ingest_published':
            current = targets[p['session']]
            original_current = p['dataset']
        elif e['action'] == 'job_submitted':
            jid = p['job']
            require(jid in jobs and jid not in submissions and current is not None,
                    'Missing or ambiguous job submission: ' + str(jid))
            require(p['dataset'] == original_current, 'Submission disagrees with publication context: ' + jid)
            submissions[jid] = (current, p['dataset'])

    final_keys = set()
    for jid, job in jobs.items():
        dataset(job['dataset'])
        target = job['dataset']
        if job['state'] == 'queued' and job['staged'] is None and job['published_run'] is None:
            require(jid in submissions, 'Queued job lacks unique submission provenance: ' + jid)
            expected, original = submissions[jid]
            if jid in moved:
                require(moved[jid]['from_dataset'] == original, 'Partial recovery job origin mismatch: ' + jid)
            else:
                require(job['dataset'] == original, 'Queued job pointer has no recovery provenance: ' + jid)
            target = expected
            if target != job['dataset']:
                entry['jobs'].append(dict(job=jid, from_dataset=job['dataset'], to_dataset=target))
        key = (target, job['policy_sha'], job['engine'])
        require(key not in final_keys, 'Recovery would collide with an existing job key: ' + jid)
        final_keys.add(key)
    if entry['sessions'] or entry['jobs'] or previews:
        require(current is not None, 'Current evidence cannot be determined')
        entry.update(status='recoverable', version=VERSION, current_dataset=current, _additions=additions)
        entry['runs'] = [dict(run=r['id'], dataset=r['dataset'], action='preserved')
                         for r in rows(db, 'SELECT id,dataset FROM runs WHERE campaign=? ORDER BY id', (cid,))]
        entry['decisions'] = [dict(decision=d['id'], run=d['run'], action='preserved')
                             for d in rows(db, 'SELECT id,run FROM decisions WHERE campaign=? ORDER BY id', (cid,))]
    return entry


def plan(db):
    studies = []
    for campaign in rows(db, 'SELECT id FROM campaigns ORDER BY id'):
        cid = campaign['id']
        try:
            entry = study_plan(db, cid)
        except (WorkbenchError, ValueError, TypeError, KeyError, AttributeError, OverflowError) as exc:
            # Evidence failures block a whole study, never a partially assembled plan.
            entry = dict(campaign=cid, status='blocked', sessions=[], jobs=[], runs=[], decisions=[],
                         unresolved=[dict(reason=str(exc))])
        studies.append(entry)
    return studies


def public(studies, mode, backup=None):
    return dict(version=VERSION, mode=mode, backup=str(backup) if backup else None,
                studies=[{k: v for k, v in entry.items() if not k.startswith('_')} for entry in studies])


def recover(path, dry_run=False, backup=None):
    path = Path(path).resolve()
    if not path.is_file():
        raise WorkbenchError('An existing database is required')
    if not dry_run:
        if backup is None or not Path(backup).is_absolute():
            raise WorkbenchError('Apply requires a new absolute backup destination')
        if os.path.lexists(backup):
            raise WorkbenchError('Choose a new backup destination')
        backup = Path(backup).resolve()
        if backup == path:
            raise WorkbenchError('Backup must not alias the input')
    db = sqlite3.connect(path.as_uri() + '?mode=' + ('ro' if dry_run else 'rw'),
                         uri=True, isolation_level=None, timeout=30)
    db.row_factory = sqlite3.Row
    try:
        db.execute('PRAGMA foreign_keys=ON')
        db.execute('BEGIN' if dry_run else 'BEGIN IMMEDIATE')
        studies = plan(db)
        if dry_run:
            db.rollback()
            return public(studies, 'dry_run')
        backup.parent.mkdir(parents=True, exist_ok=True)
        fd = os.open(backup, os.O_CREAT | os.O_EXCL | os.O_WRONLY, 0o600)
        os.close(fd)
        # The writer reservation excludes commits while a separate reader snapshots.
        reader = sqlite3.connect(path.as_uri() + '?mode=ro', uri=True)
        destination = sqlite3.connect(str(backup))
        try:
            reader.backup(destination)
        finally:
            destination.close()
            reader.close()
        for entry in studies:
            if entry['status'] != 'recoverable':
                continue
            cid = entry['campaign']
            for addition in entry['_additions']:
                db.execute('INSERT INTO datasets VALUES (?,?,?,?,?,?)',
                           (addition['id'], cid, addition['revision'], addition['sha'], dumps(addition['content']), now()))
            for correction in entry['sessions']:
                db.execute('UPDATE ingest_sessions SET published_dataset=? WHERE id=?',
                           (correction['to_dataset'], correction['session']))
            # Vacate unique keys first: even a safe final permutation may collide
            # during sequential UPDATEs. Original policy hashes are restored below.
            policies = {}
            for job in entry['jobs']:
                policies[job['job']] = db.execute('SELECT policy_sha FROM jobs WHERE id=?', (job['job'],)).fetchone()[0]
                db.execute('UPDATE jobs SET policy_sha=? WHERE id=?', ('recovery-' + uuid.uuid4().hex, job['job']))
            for job in entry['jobs']:
                db.execute("UPDATE jobs SET dataset=?,policy_sha=? WHERE id=? AND state='queued'",
                           (job['to_dataset'], policies[job['job']], job['job']))
            entry['status'] = 'recovered'
            event(db, cid, ACTION, {k: v for k, v in entry.items() if not k.startswith('_')})
        db.commit()
        return public(studies, 'apply', backup)
    except BaseException:
        db.rollback()
        raise
    finally:
        db.close()
