# Correction and retained-evidence recovery

The repaired workflow binds dataset identity to the complete original input fingerprint. The former measurement-only comparison discarded changes to volumes, revisions, lineage, and original source bytes when concentrations stayed equal. Job submission now includes the dataset in its uniqueness lookup. Transfer reports retain every binding instead of grouping by campaign, compound, and concentration.

Source staging and complete-delivery validation continue to be separate. Assembly reparses original bytes, checks both manifest and stored source fingerprints, and passes the declared transfer codec to the parser. Legacy `transfer-history/1` binding sequences are normalized before physical validation; the original text remains unchanged. Unknown codecs, invalid withdrawals, and bindings to absent samples cannot publish. Historical snapshots still read stored results without invoking the current engine.

Recovery plans each study before any mutation. It checks manifest/source integrity, publication and submission provenance, existing revisions, partial recovery mappings, and final job uniqueness. Missing or ambiguous evidence blocks the whole study. Parsed caches and display timestamps are not authorities. Existing datasets, sources, attempts, events, runs, and decisions are preserved. Only published-session pointers and eligible queued-job dataset pointers change; running/staged/completed work retains its original inputs. Matching partial-preview revisions are adopted only when their complete content and ledger provenance agree.

An apply holds `BEGIN IMMEDIATE` while taking a consistent SQLite backup through a separate reader, then commits all admitted changes and completion events atomically. Unexpected failures roll back the entire apply. Dry-run opens read-only and creates neither backup nor IDs in storage. Proposed IDs are deterministic but reserve nothing. Every apply, including an already-completed/no-change apply, requires a new absolute backup path. Existing paths, hard links, and symbolic links are rejected.

Current evidence follows journal order. A completion event records `current_dataset`; subsequent ordinary imports advance it. Reconstructing an older delivery at a higher allocated revision does not replace a later valid publication or direct import. `show.current_revision` and ingestion/review concurrency checks use the maximum allocated revision, while snapshots retain their run's actual dataset revision. Historical acceptance never transfers to reconstructed evidence.

## Executable migration and retained output

Run from this checkout, choosing a new output directory:

```sh
PYTHONPATH=src python scripts/recover_incident.py /workspace/recovery-artifacts-new
```

The executable script copies the supplied incident with SQLite's backup API and invokes the documented CLI for preview, apply, and repeat apply. It checks backup contents, exact preservation of historical rows, allowed pointer changes, preview/apply agreement, repeat safety, the supplied partial consistency diagnostic, and a historical export. No network is used. The supplied database is never modified.

The executed output is in `recovery-artifacts/`:

- `preview.json`, `apply.json`, and `repeat.json`: complete study/session/job/run/decision mappings.
- `summary.json`: executed preservation and repeat-safety checks.
- `study.db`: repaired copy; `before.db`: independently readable pre-apply backup; `repeat-before.db`: backup from no-change repeat apply.
- `consistency.json`: the supplied partial diagnostic's actual output.
- `historical-report/`: verified historical snapshot, HTML, summary CSV, transfer bindings CSV, and fingerprints.

Execution recovered **18 studies**, left **12 unaffected**, and blocked **10**. It appended **20 datasets**, recorded **24 session mappings**, and moved **24 queued jobs**. All **40 runs**, **40 review decisions**, and **100 worker attempts** remained unchanged, as did every original dataset, source, source attempt, and event. Four of the session mappings adopted existing preview datasets rather than inserting duplicates. Repeat apply added no datasets, pointer changes, or events.

The original database SHA-256 before and after execution was `bc4de222fc76eece5b91eb1a95ec7b4ee23d8de7e991bde5287a9ceea83f1a27`.

The partial consistency script reported **zero violations and 14 unresolved entries**. Ten correspond to the blocked studies below. Four others (7100, 7103, 7110, 7126) trigger that script's blanket “Later direct input requires review” condition. Recovery verified those later imports against their journal records and stored fingerprints, preserved them as current, and reconstructed only the older missing deliveries. Independent tests verify this behavior for both later direct imports and later instrument publications. The partial checker is intentionally not a full recovery oracle; its unresolved output is retained without suppression.

## Blocked studies

No changes were applied to these studies. Each requires original missing evidence or an authoritative provenance/format resolution; cached parsing or inferred timestamps are insufficient.

| Study | Campaign ID | Recorded blocker |
| --- | --- | --- |
| Screening study 7102 | `18777fb11c3f4161ad5b9b159867dde8` | Missing original source bytes: f6e98a0f441f4008a2151a68641ba7d5 |
| Screening study 7104 | `a9f225a576ce44bdad197d5d2c05fb51` | Missing original source bytes: 9c991a671e1e4cf7bf8d12a79a12d8ba |
| Screening study 7108 | `f082fa4fc4844a3ebff5d737204dbfc1` | Queued job lacks unique submission provenance: 3c5336b236264c3a93e44b929f5ca658 |
| Screening study 7109 | `115de33b245042faa8ee3bd3ddb289bd` | Queued job lacks unique submission provenance: 20650986a07c4e9e93794377e3aa0d84 |
| Screening study 7112 | `88c454cf4e314193922389580cd44766` | Queued job lacks unique submission provenance: 735e3506954c4ef08c911228fda426fe |
| Screening study 7118 | `0a70e2995cec4829a4e30b94153521f6` | Missing original source bytes: d7d3da2698994276bd71e31a2a76e7e1 |
| Screening study 7122 | `6c9b34b96363425cb44be867950c6957` | Missing original source bytes: 16f8065e8e5a489eae367a28a8f5abc0 |
| Screening study 7123 | `b72b611d310c4e5a953fed8cc6b7a326` | Queued job lacks unique submission provenance: 7c7cd9abc0ed4aa5939bfb65181450c7 |
| Screening study 7133 | `259c706e496b477788c07d033e47b317` | Missing or inconsistent opening provenance: 2c416fae4c8a463eb2c16a3fa2b332b6 |
| Screening study 7135 | `e3f589589e8d4a53af162c3b8d5409b0` | Missing or inconsistent opening provenance: ef19f45191fb492e8a4bde5b5557f138 |

Studies 7102, 7104, 7118, and 7122 lack original transfer source bytes. Restore verified bytes matching both retained fingerprint records before retrying. Studies 7108, 7109, 7112, and 7123 lack a queued job's unique submission event; evidence must establish its submission context before that job can be repinned. Studies 7133 and 7135 have manifests that disagree with the opening journal and declare `transfer-history/unknown`; both discrepancies need authoritative resolution. Merely changing the codec label is not a safe repair.

## Validation

`PYTHONPATH=src python -m pytest -q`: **64 passed**.

Added independent recovery regressions cover stale parsed caches, reversed display timestamps, legacy codec normalization with preserved bytes, malformed and incomplete inputs, unsupported codecs, unmatched bindings, physical overdraws, submission ambiguity, final job-key collisions, partial-ledger adoption and rejection, newer-current preservation, all-or-nothing rollback, backups including committed WAL content, alias rejection, repeat safety, and distinct report wells. Existing lifecycle tests cover flat/campaign corrections, byte-level identity, worker pinning before and after compute, lease fencing, review retirement, and historical compatibility.

The executed migration additionally checked every original dataset and event, every historical result/review/attempt, and every allowed pointer update against the pre-apply database. `summary.json` reports the actual execution results.
