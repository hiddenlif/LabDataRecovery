"""Independent histories exercise recovery's safety and ordering boundaries."""
import csv
import hashlib
import sqlite3

import pytest

from truegate.codec import digest, dumps, loads
from truegate.database import transaction
from truegate.errors import WorkbenchError
from truegate.ingestion import Ingestion
from truegate.jobs import Jobs
from truegate.recovery import PREVIEW, recover
from truegate.reporting import export, verify
from truegate.repository import Repository, event
from test_correction_lifecycle import evidence, correction, stage


def snapshot(path):
    with sqlite3.connect(path) as db:
        return {name: db.execute(f'SELECT * FROM {name} ORDER BY rowid').fetchall()
                for name, in db.execute("SELECT name FROM sqlite_master WHERE type='table'")}


def incident(path, monkeypatch, *, later=None, codec=None):
    repo, ingest, jobs = Repository(path), Ingestion(path), Jobs(path)
    cid = repo.create('Independent retained study', 'screening')['campaign']
    original = evidence()
    first, _ = stage(ingest, cid, original, 'first', 0)
    d1 = ingest.publish(first)
    completed = jobs.submit(cid)['job']
    token = jobs.claim(completed, 'worker')['token']
    jobs.compute(completed, token)
    run = jobs.publish(completed, token)['run']
    repo.review(cid, run, 'accept', 'Scientist', 'Original inspected', 1)
    before = jobs.submit(cid, {'max_ic50_um': 3})['job']
    running = jobs.submit(cid, {'max_ic50_um': 4})['job']
    token = jobs.claim(running, 'staged')['token']
    jobs.compute(running, token)
    second, _ = stage(ingest, cid, correction(original), 'second', 1)
    if codec:
        with transaction(path) as db:
            s = db.execute('SELECT * FROM ingest_sessions WHERE id=?', (second,)).fetchone()
            manifest = loads(s['manifest'])
            raw = db.execute("SELECT raw FROM ingest_sources WHERE session=? AND source_id='transfer_history'", (second,)).fetchone()[0]
            model = loads(raw)
            for b in model['bindings']:
                b['sequence'] += 1
            raw = dumps(model).encode()
            sha = hashlib.sha256(raw).hexdigest()
            spec = next(s for s in manifest['sources'] if s['kind'] == 'transfer_history')
            spec.update(codec=codec, sha256=sha)
            db.execute('UPDATE ingest_sessions SET manifest=?,manifest_sha=? WHERE id=?', (dumps(manifest), digest(manifest), second))
            db.execute("UPDATE ingest_sources SET raw=?,sha=? WHERE session=? AND source_id='transfer_history'", (raw, sha, second))
            opened = db.execute("SELECT id,payload FROM events WHERE action='ingest_opened' AND campaign=? ORDER BY id DESC LIMIT 1", (cid,)).fetchone()
            payload = loads(opened['payload']); payload['manifest_sha256'] = digest(manifest)
            db.execute('UPDATE events SET payload=? WHERE id=?', (dumps(payload), opened['id']))
    # Reproduce the former numerical-projection reuse at the storage boundary.
    with monkeypatch.context() as patch:
        patch.setattr('truegate.ingestion.store_dataset', lambda *args: dict(d1, reused=True))
        ingest.publish(second)
    after = jobs.submit(cid, {'max_ic50_um': 5})['job']
    latest = None
    if later:
        changed = correction(original)
        changed['transfer_history']['revision'] = 'later'
        if later == 'publication':
            third, _ = stage(ingest, cid, changed, 'third', 1)
            latest = ingest.publish(third)
        else:
            latest = repo.import_data(cid, changed)
    return dict(campaign=cid, first=first, second=second, original=d1['dataset'],
                before=before, after=after, running=running, run=run, latest=latest)


def entry(report, ids):
    return next(s for s in report['studies'] if s['campaign'] == ids['campaign'])


def test_reconcile_preserves_history_backup_and_repeat(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    ids = incident(path, monkeypatch)
    with transaction(path) as db:
        db.execute("UPDATE ingest_sources SET parsed='garbage'")
        db.execute("UPDATE events SET created=CAST(10000-id AS TEXT)")
    before = snapshot(path)
    raw = path.read_bytes()
    plan = recover(path, dry_run=True)
    assert path.read_bytes() == raw and snapshot(path) == before
    assert sorted(p.name for p in tmp_path.iterdir()) == ['study.db']
    p = entry(plan, ids)
    assert p['status'] == 'recoverable'
    assert [j['job'] for j in p['jobs']] == [ids['after']]
    applied = entry(recover(path, backup=tmp_path / 'backup.db'), ids)
    assert applied == dict(p, status='recovered')
    assert snapshot(tmp_path / 'backup.db') == before
    result = snapshot(path)
    for table in ['runs', 'decisions', 'ingest_sources', 'ingest_attempts', 'job_attempts']:
        assert result[table] == before[table]
    assert result['datasets'][:len(before['datasets'])] == before['datasets']
    assert result['events'][:len(before['events'])] == before['events']
    repo = Repository(path)
    assert repo.show(ids['campaign'])['current_review'] is None
    snap = repo.snapshot(ids['campaign'], ids['run'])
    assert snap['superseded'] and snap['review']['action'] == 'accept'
    export(snap, tmp_path / 'report')
    assert verify(tmp_path / 'report')['verified']
    with (tmp_path / 'report' / 'transfer-bindings.csv').open() as f:
        assert {r['record_id'] for r in csv.DictReader(f)} == {'early', 'late'}
    assert entry(recover(path, dry_run=True), ids) == dict(applied, status='already_recovered')
    recover(path, backup=tmp_path / 'repeat.db')
    assert snapshot(path) == result
    assert snapshot(tmp_path / 'repeat.db') == result


@pytest.mark.parametrize('later', ['publication', 'direct'])
def test_recovery_appends_old_input_without_replacing_later_current(tmp_path, monkeypatch, later):
    path = tmp_path / 'study.db'
    ids = incident(path, monkeypatch, later=later)
    repo = Repository(path)
    current = repo.run(ids['campaign'])['run']
    repo.review(ids['campaign'], current, 'accept', 'Scientist', 'Newer input', 2)
    recover(path, backup=tmp_path / 'backup.db')
    show = repo.show(ids['campaign'])
    assert show['current_review']['run'] == current
    assert show['current_revision'] == 3  # allocation/concurrency token stays monotonic
    assert not repo.snapshot(ids['campaign'], current)['superseded']
    assert repo.run(ids['campaign'])['run'] == current
    repo.review(ids['campaign'], current, 'hold', 'Scientist', 'Still current', 3)
    with transaction(path) as db:
        assert db.execute('SELECT dataset FROM jobs WHERE id=?', (ids['after'],)).fetchone()[0] != ids['latest']['dataset']
    changed = correction(evidence()); changed['transfer_history']['revision'] = 'newest'
    assert repo.import_data(ids['campaign'], changed)['revision'] == 4
    assert repo.show(ids['campaign'])['current_review'] is None
    assert repo.snapshot(ids['campaign'], current)['superseded']


def test_legacy_codec_is_applied_before_validation(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    ids = incident(path, monkeypatch, codec='transfer-history/1')
    p = entry(recover(path, backup=tmp_path / 'backup.db'), ids)
    assert p['status'] == 'recovered'
    with transaction(path) as db:
        d = db.execute('SELECT content FROM datasets WHERE id=?', (p['sessions'][0]['to_dataset'],)).fetchone()
        content = loads(d['content'])
        assert [b['sequence'] for b in content['transfer_history']['bindings']] == [1, 2]
        source = next(s for s in content['ingestion']['sources'] if s['kind'] == 'transfer_history')
        assert [b['sequence'] for b in loads(source['text'])['bindings']] == [2, 3]


@pytest.mark.parametrize('damage', ['missing_bytes', 'source_sha', 'manifest_sha', 'missing_source',
                                    'missing_publication', 'duplicate_submission', 'missing_submission',
                                    'malformed_manifest', 'key_collision'])
def test_bad_evidence_blocks_whole_study_but_not_neighbors(tmp_path, monkeypatch, damage):
    path = tmp_path / 'study.db'
    bad = incident(path, monkeypatch)
    good = incident(path, monkeypatch)
    with transaction(path) as db:
        if damage in {'missing_bytes', 'source_sha'}:
            column, value = ('raw', None) if damage == 'missing_bytes' else ('sha', '0' * 64)
            db.execute(f'UPDATE ingest_sources SET {column}=? WHERE session=?', (value, bad['second']))
        elif damage in {'manifest_sha', 'malformed_manifest'}:
            column, value = ('manifest_sha', 'bad') if damage == 'manifest_sha' else ('manifest', '[]')
            db.execute(f'UPDATE ingest_sessions SET {column}=? WHERE id=?', (value, bad['second']))
        elif damage == 'missing_source':
            db.execute('DELETE FROM ingest_attempts WHERE session=?', (bad['second'],))
            db.execute('DELETE FROM ingest_sources WHERE session=?', (bad['second'],))
        elif damage == 'missing_publication':
            db.execute("DELETE FROM events WHERE campaign=? AND action='ingest_published'", (bad['campaign'],))
        elif damage == 'key_collision':
            # A second historical queued job shares the recovered destination/key.
            p = entry(recover_plan(db), bad)
            m = p['sessions'][0]
            content = retained_input(db, bad['second'])
            db.execute('INSERT INTO datasets VALUES (?,?,?,?,?,?)', (m['to_dataset'], bad['campaign'], 2, digest(content), dumps(content), 'old'))
            event(db, bad['campaign'], PREVIEW, dict(version='transfer-evidence-preview-0', sessions=[m], jobs=[]))
            job = dict(db.execute('SELECT * FROM jobs WHERE id=?', (bad['after'],)).fetchone())
            job.update(id='collision-job', dataset=m['to_dataset'], state='running')
            db.execute('INSERT INTO jobs (' + ','.join(job) + ') VALUES (' + ','.join('?' for _ in job) + ')', tuple(job.values()))
        else:
            events = db.execute("SELECT * FROM events WHERE campaign=? AND action='job_submitted'", (bad['campaign'],)).fetchall()
            e = next(e for e in events if loads(e['payload'])['job'] == bad['after'])
            if damage == 'missing_submission':
                db.execute('DELETE FROM events WHERE id=?', (e['id'],))
            else:
                event(db, bad['campaign'], 'job_submitted', loads(e['payload']))
    before = snapshot(path)
    result = recover(path, backup=tmp_path / 'backup.db')
    blocked = entry(result, bad)
    assert blocked['status'] == 'blocked' and blocked['unresolved']
    assert all(blocked[k] == [] for k in ['sessions', 'jobs', 'runs', 'decisions'])
    assert entry(result, good)['status'] == 'recovered'
    after = snapshot(path)
    # All old rows except the admitted study's publication and queued-job pointers survive.
    for table in ['datasets', 'events', 'runs', 'decisions', 'ingest_sources', 'job_attempts']:
        assert all(row in after[table] for row in before[table])
    for table in ['jobs', 'ingest_sessions']:
        assert all(row in after[table] for row in before[table] if row[1] == bad['campaign'])


def recover_plan(db):
    from truegate.recovery import plan, public
    return public(plan(db), 'dry_run')


def retained_input(db, session):
    from truegate.ingest_resolution import assemble
    manifest = loads(db.execute('SELECT manifest FROM ingest_sessions WHERE id=?', (session,)).fetchone()[0])
    return assemble(manifest, db.execute('SELECT * FROM ingest_sources WHERE session=?', (session,)).fetchall())


def test_partial_ledger_adopts_revisions_and_restores_submission_context(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    ids = incident(path, monkeypatch)
    p = entry(recover(path, dry_run=True), ids)
    mapping = p['sessions'][0]
    with transaction(path) as db:
        content = retained_input(db, ids['second'])
        db.execute('INSERT INTO datasets VALUES (?,?,?,?,?,?)', (mapping['to_dataset'], ids['campaign'], 2, digest(content), dumps(content), 'old'))
        moves = [dict(job=ids[key], from_dataset=ids['original'], to_dataset=mapping['to_dataset']) for key in ['before', 'after']]
        for m in moves:
            db.execute('UPDATE jobs SET dataset=? WHERE id=?', (m['to_dataset'], m['job']))
        event(db, ids['campaign'], PREVIEW, dict(version='transfer-evidence-preview-0', sessions=[mapping], jobs=moves))
    before = snapshot(path)
    p = entry(recover(path, backup=tmp_path / 'backup.db'), ids)
    assert p['status'] == 'recovered'
    assert p['jobs'] == [dict(job=ids['before'], from_dataset=mapping['to_dataset'], to_dataset=ids['original'])]
    after = snapshot(path)
    assert before['datasets'] == after['datasets']
    assert all(e in after['events'] for e in before['events'])


def test_apply_failure_rolls_back_all_studies_and_keeps_readable_backup(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    incident(path, monkeypatch); incident(path, monkeypatch)
    before = snapshot(path)
    calls = []
    def fail(db, cid, action, payload):
        calls.append(cid)
        event(db, cid, action, payload)
        if len(calls) == 2:
            raise RuntimeError('injected failure after writes')
    monkeypatch.setattr('truegate.recovery.event', fail)
    with pytest.raises(RuntimeError, match='injected'):
        recover(path, backup=tmp_path / 'backup.db')
    assert len(calls) == 2
    assert snapshot(path) == before == snapshot(tmp_path / 'backup.db')


def test_backup_rejects_aliases_and_snapshots_wal(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    ids = incident(path, monkeypatch)
    with sqlite3.connect(path) as writer:
        writer.execute('PRAGMA journal_mode=WAL')
        writer.execute("UPDATE campaigns SET name='WAL commit' WHERE id=?", (ids['campaign'],))
        writer.commit()
        before = snapshot(path)
        alias = tmp_path / 'alias.db'; alias.hardlink_to(path)
        for destination in [None, path, alias, 'relative.db']:
            with pytest.raises(WorkbenchError):
                recover(path, backup=destination)
        assert snapshot(path) == before
        recover(path, backup=tmp_path / 'backup.db')
        assert snapshot(tmp_path / 'backup.db') == before


@pytest.mark.parametrize('damage', ['unknown_codec', 'bad_sequence', 'unmatched', 'overdraw'])
def test_invalid_retained_transfer_is_blocked(tmp_path, monkeypatch, damage):
    path = tmp_path / 'study.db'
    ids = incident(path, monkeypatch)
    with transaction(path) as db:
        sid = ids['second']
        manifest = loads(db.execute('SELECT manifest FROM ingest_sessions WHERE id=?', (sid,)).fetchone()[0])
        spec = next(s for s in manifest['sources'] if s['kind'] == 'transfer_history')
        raw = db.execute('SELECT raw FROM ingest_sources WHERE session=? AND source_id=?', (sid, spec['id'])).fetchone()[0]
        model = loads(raw)
        if damage == 'unknown_codec':
            spec['codec'] = 'transfer-history/unknown'
        elif damage == 'bad_sequence':
            spec['codec'] = 'transfer-history/1'
            model['bindings'][0]['sequence'] = True
        elif damage == 'unmatched':
            model['bindings'][0]['record_id'] = 'missing-sample'
        else:
            model['events'][0]['volume'] = 1
        raw = dumps(model).encode()
        spec['sha256'] = hashlib.sha256(raw).hexdigest()
        db.execute('UPDATE ingest_sources SET raw=?,sha=? WHERE session=? AND source_id=?', (raw, spec['sha256'], sid, spec['id']))
        db.execute('UPDATE ingest_sessions SET manifest=?,manifest_sha=? WHERE id=?', (dumps(manifest), digest(manifest), sid))
        e = db.execute("SELECT id,payload FROM events WHERE campaign=? AND action='ingest_opened' ORDER BY id DESC LIMIT 1", (ids['campaign'],)).fetchone()
        payload = loads(e['payload']); payload['manifest_sha256'] = digest(manifest)
        db.execute('UPDATE events SET payload=? WHERE id=?', (dumps(payload), e['id']))
    before = snapshot(path)
    result = entry(recover(path, backup=tmp_path / 'backup.db'), ids)
    assert result['status'] == 'blocked'
    assert snapshot(path) == before


def test_mismatching_partial_recovery_is_not_guessed(tmp_path, monkeypatch):
    path = tmp_path / 'study.db'
    ids = incident(path, monkeypatch)
    p = entry(recover(path, dry_run=True), ids)
    mapping = p['sessions'][0]
    with transaction(path) as db:
        content = retained_input(db, ids['second'])
        content['transfer_history']['revision'] = 'unverifiable'
        db.execute('INSERT INTO datasets VALUES (?,?,?,?,?,?)', (mapping['to_dataset'], ids['campaign'], 2, digest(content), dumps(content), 'old'))
        event(db, ids['campaign'], PREVIEW, dict(version='transfer-evidence-preview-0', sessions=[mapping], jobs=[]))
    before = snapshot(path)
    assert entry(recover(path, backup=tmp_path / 'backup.db'), ids)['status'] == 'blocked'
    assert snapshot(path) == before
